using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using HidSharp;

namespace PulseMute
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            AppDomain.CurrentDomain.AssemblyResolve += LoadEmbeddedAssembly;
            EnableDpiAwareness();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }

        private static Assembly LoadEmbeddedAssembly(object sender, ResolveEventArgs args)
        {
            if (!string.Equals(new AssemblyName(args.Name).Name, "HidSharp", StringComparison.OrdinalIgnoreCase))
                return null;

            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("HidSharp.dll"))
            {
                if (stream == null)
                    return null;
                byte[] bytes = new byte[stream.Length];
                int offset = 0;
                while (offset < bytes.Length)
                {
                    int count = stream.Read(bytes, offset, bytes.Length - offset);
                    if (count <= 0)
                        break;
                    offset += count;
                }
                return Assembly.Load(bytes);
            }
        }

        private static void EnableDpiAwareness()
        {
            try
            {
                if (SetProcessDpiAwarenessContext(new IntPtr(-4)))
                    return;
            }
            catch
            {
            }

            try
            {
                SetProcessDPIAware();
            }
            catch
            {
            }
        }

        [DllImport("user32.dll")]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr dpiContext);

        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();
    }

    internal sealed class MainForm : Form
    {
        private static readonly int DesignVariant = 0;
        private const int WhKeyboardLl = 13;
        private const int WhMouseLl = 14;
        private const int WmKeydown = 0x0100;
        private const int WmKeyup = 0x0101;
        private const int WmSyskeydown = 0x0104;
        private const int WmSyskeyup = 0x0105;
        private const int GaRoot = 2;
        private const uint GwOwner = 4;
        private const uint LlMhfInjected = 0x00000001;

        private readonly MicController mic = new MicController();
        private readonly DualSenseControllerService dualSense = new DualSenseControllerService();
        private readonly Icon appIcon;
        private readonly NotifyIcon tray;
        private readonly Timer refreshTimer;
        private readonly Label titleLabel;
        private readonly Label statusLabel;
        private readonly Label deviceLabel;
        private readonly Label shortcutLabel;
        private readonly Label shortcutValueLabel;
        private readonly Button shortcutButton;
        private readonly Label shortcutTwoLabel;
        private readonly Label shortcutTwoValueLabel;
        private readonly Button shortcutTwoButton;
        private readonly Button settingsButton;
        private readonly Button topButton;
        private readonly Button refreshButton;
        private readonly Button hideButton;
        private readonly Label creditLabel;
        private readonly Panel creditRuleLeft;
        private readonly Panel creditRuleRight;
        private readonly ToolTip toolTips;
        private readonly RoundButton toggleButton;
        private readonly LowLevelKeyboardProc keyboardProc;
        private readonly LowLevelMouseProc mouseProc;
        private IntPtr keyboardHook = IntPtr.Zero;
        private IntPtr mouseHook = IntPtr.Zero;
        private uint currentKey = (uint)Keys.F8;
        private ShortcutSource shortcutSource = ShortcutSource.Keyboard;
        private DualSenseButton currentControllerButton = DualSenseButton.MicrophoneMute;
        private MouseHotkey currentMouseButton = MouseHotkey.Middle;
        private uint secondKey = (uint)Keys.F9;
        private ShortcutSource secondShortcutSource = ShortcutSource.Keyboard;
        private DualSenseButton secondControllerButton = DualSenseButton.Touchpad;
        private MouseHotkey secondMouseButton = MouseHotkey.XButton1;
        private int captureShortcutSlot;
        private bool shortcutOneHeld;
        private bool shortcutTwoHeld;
        private bool stayOnTop;
        private bool hideFromTaskbar;
        private bool rememberWindowPlacement = true;
        private bool darkMode = true;
        private bool customColorsEnabled;
        private Color customAccentColor = Color.FromArgb(34, 139, 111);
        private Color customCreatorColor = Color.FromArgb(193, 53, 69);
        private Color customBackgroundColor = Color.FromArgb(17, 20, 24);
        private Color customSurfaceColor = Color.FromArgb(28, 33, 40);
        private Color customPrimaryTextColor = Color.FromArgb(238, 241, 245);
        private Color customSecondaryTextColor = Color.FromArgb(139, 149, 161);
        private bool windowSettingsReady;

        public MainForm()
        {
            keyboardProc = KeyboardHookCallback;
            mouseProc = MouseHookCallback;
            appIcon = LoadAppIcon();

            Text = "PulseMute Test";
            Icon = appIcon;
            Width = 300;
            Height = 380;
            MinimumSize = new Size(220, 300);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(17, 20, 24);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 10F);
            AutoScaleMode = AutoScaleMode.Dpi;
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            ConfigureEditionWindow();

            titleLabel = new Label();
            titleLabel.Text = "PulseMute Test";
            titleLabel.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold);
            titleLabel.AutoSize = false;
            titleLabel.AutoEllipsis = true;
            titleLabel.Location = new Point(18, 18);

            statusLabel = new Label();
            statusLabel.Text = "Checking...";
            statusLabel.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            statusLabel.AutoSize = false;
            statusLabel.TextAlign = ContentAlignment.MiddleCenter;
            statusLabel.Location = new Point(189, 23);
            statusLabel.Size = new Size(74, 28);
            statusLabel.BackColor = Color.FromArgb(47, 58, 68);
            statusLabel.ForeColor = Color.White;

            deviceLabel = new Label();
            deviceLabel.Text = "Default microphone";
            deviceLabel.AutoEllipsis = true;
            deviceLabel.Location = new Point(20, 64);
            deviceLabel.Size = new Size(242, 24);
            deviceLabel.ForeColor = Color.FromArgb(180, 190, 200);

            toggleButton = new RoundButton();
            toggleButton.Location = new Point(79, 92);
            toggleButton.Size = new Size(126, 126);
            toggleButton.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
            toggleButton.Text = "Toggle";
            toggleButton.Cursor = Cursors.Hand;
            toggleButton.Click += delegate { ToggleMute(); };

            shortcutLabel = new Label();
            shortcutLabel.Text = "KEY 1";
            shortcutLabel.AutoSize = false;
            shortcutLabel.TextAlign = ContentAlignment.MiddleLeft;
            shortcutLabel.Location = new Point(20, 229);
            shortcutLabel.Size = new Size(42, 24);
            shortcutLabel.ForeColor = Color.FromArgb(144, 154, 166);

            shortcutValueLabel = new Label();
            shortcutValueLabel.Text = CurrentShortcutText(1);
            shortcutValueLabel.AutoEllipsis = true;
            shortcutValueLabel.TextAlign = ContentAlignment.MiddleCenter;
            shortcutValueLabel.BorderStyle = BorderStyle.FixedSingle;
            shortcutValueLabel.Location = new Point(62, 229);
            shortcutValueLabel.Size = new Size(90, 24);
            shortcutValueLabel.ForeColor = Color.FromArgb(226, 231, 235);

            toolTips = new ToolTip();
            toolTips.AutoPopDelay = 5000;
            toolTips.InitialDelay = 450;

            shortcutButton = CreateSmallButton("\uE70F", new Point(229, 224));
            shortcutButton.Size = new Size(34, 30);
            shortcutButton.Font = new Font("Segoe Fluent Icons", 11F, FontStyle.Regular);
            shortcutButton.AccessibleName = "Change global hotkey";
            toolTips.SetToolTip(shortcutButton, "Change global hotkey");
            shortcutButton.Click += delegate
            {
                captureShortcutSlot = 1;
                shortcutValueLabel.Text = "Listening...";
                shortcutButton.Focus();
            };
            shortcutButton.KeyDown += CaptureShortcut;

            shortcutTwoLabel = new Label();
            shortcutTwoLabel.Text = "KEY 2";
            shortcutTwoLabel.AutoSize = false;
            shortcutTwoLabel.TextAlign = ContentAlignment.MiddleLeft;
            shortcutTwoLabel.ForeColor = Color.FromArgb(144, 154, 166);

            shortcutTwoValueLabel = new Label();
            shortcutTwoValueLabel.Text = CurrentShortcutText(2);
            shortcutTwoValueLabel.AutoEllipsis = true;
            shortcutTwoValueLabel.TextAlign = ContentAlignment.MiddleCenter;
            shortcutTwoValueLabel.BorderStyle = BorderStyle.FixedSingle;
            shortcutTwoValueLabel.ForeColor = Color.FromArgb(226, 231, 235);

            shortcutTwoButton = CreateSmallButton("\uE70F", new Point(229, 252));
            shortcutTwoButton.Size = new Size(34, 30);
            shortcutTwoButton.Font = new Font("Segoe Fluent Icons", 11F, FontStyle.Regular);
            shortcutTwoButton.AccessibleName = "Change second global hotkey";
            toolTips.SetToolTip(shortcutTwoButton, "Change Key 2");
            shortcutTwoButton.Click += delegate
            {
                captureShortcutSlot = 2;
                shortcutTwoValueLabel.Text = "Listening...";
                shortcutTwoButton.Focus();
            };
            shortcutTwoButton.KeyDown += CaptureShortcut;

            settingsButton = CreateSmallButton("\uE713", new Point(72, 22));
            settingsButton.Size = new Size(32, 28);
            settingsButton.Font = new Font("Segoe Fluent Icons", 11F, FontStyle.Regular);
            settingsButton.AccessibleName = "Settings";
            settingsButton.Click += delegate { ShowSettingsV15(); };
            toolTips.SetToolTip(settingsButton, "Settings");

            topButton = CreateSmallButton("\uE718", new Point(108, 286));
            topButton.Size = new Size(34, 28);
            topButton.Font = new Font("Segoe Fluent Icons", 11F, FontStyle.Regular);
            topButton.AccessibleName = "Stay on top";
            toolTips.SetToolTip(topButton, "Stay on top");
            topButton.Click += delegate { ToggleStayOnTop(); };

            creditLabel = new Label();
            creditLabel.Text = "BUILT BY WRAKEEB";
            creditLabel.AutoSize = false;
            creditLabel.TextAlign = ContentAlignment.MiddleCenter;
            creditLabel.Location = new Point(58, 261);
            creditLabel.Size = new Size(168, 20);
            creditLabel.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            creditLabel.ForeColor = Color.FromArgb(170, 180, 191);

            creditRuleLeft = new Panel();
            creditRuleLeft.BackColor = Color.FromArgb(193, 53, 69);
            creditRuleRight = new Panel();
            creditRuleRight.BackColor = Color.FromArgb(193, 53, 69);

            refreshButton = CreateSmallButton("\uE72C", new Point(20, 286));
            refreshButton.Size = new Size(40, 28);
            refreshButton.Font = new Font("Segoe Fluent Icons", 11F, FontStyle.Regular);
            refreshButton.AccessibleName = "Refresh microphone state";
            toolTips.SetToolTip(refreshButton, "Refresh microphone state");
            refreshButton.Click += delegate { RefreshState(); };

            hideButton = CreateSmallButton("\uE70D", new Point(223, 286));
            hideButton.Size = new Size(40, 28);
            hideButton.Font = new Font("Segoe Fluent Icons", 11F, FontStyle.Regular);
            hideButton.AccessibleName = "Hide to tray";
            toolTips.SetToolTip(hideButton, "Hide to tray");
            hideButton.Click += delegate { HideToTray(); };

            Controls.Add(titleLabel);
            Controls.Add(statusLabel);
            Controls.Add(deviceLabel);
            Controls.Add(toggleButton);
            Controls.Add(shortcutLabel);
            Controls.Add(shortcutValueLabel);
            Controls.Add(shortcutButton);
            Controls.Add(shortcutTwoLabel);
            Controls.Add(shortcutTwoValueLabel);
            Controls.Add(shortcutTwoButton);
            Controls.Add(settingsButton);
            Controls.Add(topButton);
            Controls.Add(creditRuleLeft);
            Controls.Add(creditLabel);
            Controls.Add(creditRuleRight);
            Controls.Add(refreshButton);
            Controls.Add(hideButton);

            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.Add("Show", null, delegate { ShowFromTray(); });
            menu.Items.Add("Toggle mute", null, delegate { ToggleMute(); });
            menu.Items.Add("Exit", null, delegate { Close(); });

            tray = new NotifyIcon();
            tray.Text = "PulseMute Test";
            tray.Icon = appIcon;
            tray.ContextMenuStrip = menu;
            tray.Visible = true;
            tray.DoubleClick += delegate { ShowFromTray(); };

            refreshTimer = new Timer();
            refreshTimer.Interval = 1200;
            refreshTimer.Tick += delegate { RefreshState(); };
            refreshTimer.Start();

            dualSense.ButtonPressed += DualSenseButtonPressed;

            Load += delegate
            {
                LoadShortcut();
                LoadWindowSettings();
                ApplyTheme();
                InstallKeyboardHook();
                InstallMouseHook();
                dualSense.Start();
                RefreshState();
                windowSettingsReady = true;
            };
            FormClosing += delegate
            {
                SaveWindowSettings();
                UninstallKeyboardHook();
                UninstallMouseHook();
                dualSense.Stop();
                tray.Visible = false;
                tray.Dispose();
            };
            Move += delegate { SaveWindowSettings(); };
            ResizeEnd += delegate { SaveWindowSettings(); };
            Resize += delegate
            {
                if (WindowState == FormWindowState.Minimized)
                    HideToTray();
                else
                    ApplyResponsiveLayout();
            };

            ApplyEditionIdentity();
            ApplyResponsiveLayout();
        }

        private void ConfigureEditionWindow()
        {
            if (DesignVariant == 1)
            {
                Width = 520;
                Height = 290;
                MinimumSize = new Size(380, 240);
            }
            else if (DesignVariant == 2)
            {
                Width = 340;
                Height = 500;
                MinimumSize = new Size(250, 380);
            }
            else if (DesignVariant == 3)
            {
                Width = 470;
                Height = 320;
                MinimumSize = new Size(350, 250);
            }
        }

        private void ApplyEditionIdentity()
        {
            if (DesignVariant == 1)
            {
                titleLabel.Text = "PulseMute / Focus";
                toggleButton.ShapeStyle = 0;
            }
            else if (DesignVariant == 2)
            {
                titleLabel.Text = "PulseMute Signal";
                toggleButton.ShapeStyle = 1;
            }
            else if (DesignVariant == 3)
            {
                titleLabel.Text = "PULSEMUTE CONSOLE";
                toggleButton.ShapeStyle = 2;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            ApplyCaptionTheme(Handle, darkMode);
        }

        private Button CreateSmallButton(string text, Point location)
        {
            Button button = new Button();
            button.Text = text;
            button.Location = location;
            button.Size = new Size(82, 32);
            button.FlatStyle = FlatStyle.Flat;
            button.BackColor = Color.FromArgb(31, 36, 43);
            button.ForeColor = Color.White;
            button.Cursor = Cursors.Hand;
            button.FlatAppearance.BorderColor = Color.FromArgb(54, 62, 72);
            button.FlatAppearance.MouseOverBackColor = Color.FromArgb(42, 49, 59);
            return button;
        }

        private static Icon LoadAppIcon()
        {
            try
            {
                Icon extracted = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                if (extracted != null)
                    return extracted;
            }
            catch
            {
            }

            return IconFactory.Create(false, false);
        }

        private void ApplyTheme()
        {
            Color background = ThemeBackgroundColor();
            Color primaryText = ThemePrimaryTextColor();
            Color secondaryText = ThemeSecondaryTextColor();
            Color mutedText = customColorsEnabled ? customSecondaryTextColor : (darkMode ? Color.FromArgb(144, 154, 166) : Color.FromArgb(96, 106, 118));

            BackColor = background;
            ForeColor = primaryText;
            titleLabel.ForeColor = primaryText;
            deviceLabel.ForeColor = secondaryText;
            shortcutLabel.ForeColor = mutedText;
            shortcutValueLabel.ForeColor = primaryText;
            shortcutValueLabel.BackColor = ThemeSurfaceColor();
            shortcutTwoLabel.ForeColor = mutedText;
            shortcutTwoValueLabel.ForeColor = primaryText;
            shortcutTwoValueLabel.BackColor = ThemeSurfaceColor();
            creditLabel.ForeColor = secondaryText;
            creditRuleLeft.BackColor = CreatorLineColor();
            creditRuleRight.BackColor = CreatorLineColor();

            ApplyButtonTheme(shortcutButton);
            ApplyButtonTheme(shortcutTwoButton);
            ApplyButtonTheme(settingsButton);
            ApplyButtonTheme(topButton);
            ApplyButtonTheme(refreshButton);
            ApplyButtonTheme(hideButton);
            if (stayOnTop)
            {
                topButton.BackColor = Color.FromArgb(26, 124, 88);
                topButton.ForeColor = Color.White;
            }

            ApplyCaptionTheme(Handle, darkMode);
            Invalidate(true);
        }

        private void ApplyButtonTheme(Button button)
        {
            Color darkSurface = DesignVariant == 1 ? Color.FromArgb(24, 34, 38) :
                DesignVariant == 2 ? Color.FromArgb(35, 37, 43) :
                DesignVariant == 3 ? Color.FromArgb(25, 31, 35) : Color.FromArgb(31, 36, 43);
            button.BackColor = customColorsEnabled ? customSurfaceColor : (darkMode ? darkSurface : Color.White);
            button.ForeColor = customColorsEnabled ? customPrimaryTextColor : (darkMode ? Color.White : Color.FromArgb(32, 37, 44));
            button.FlatAppearance.BorderColor = darkMode ? Color.FromArgb(54, 62, 72) : Color.FromArgb(195, 202, 211);
            button.FlatAppearance.MouseOverBackColor = darkMode ? Color.FromArgb(42, 49, 59) : Color.FromArgb(232, 236, 241);
        }

        private Color AccentColor()
        {
            if (customColorsEnabled)
                return customAccentColor;
            if (DesignVariant == 1)
                return Color.FromArgb(35, 166, 173);
            if (DesignVariant == 2)
                return Color.FromArgb(63, 111, 198);
            if (DesignVariant == 3)
                return Color.FromArgb(217, 151, 55);
            return Color.FromArgb(34, 139, 111);
        }

        private Color CreatorLineColor()
        {
            return customColorsEnabled ? customCreatorColor : Color.FromArgb(193, 53, 69);
        }

        private Color ThemeBackgroundColor()
        {
            if (customColorsEnabled)
                return customBackgroundColor;
            if (DesignVariant == 1)
                return darkMode ? Color.FromArgb(12, 20, 23) : Color.FromArgb(243, 248, 248);
            if (DesignVariant == 2)
                return darkMode ? Color.FromArgb(22, 23, 27) : Color.FromArgb(248, 249, 251);
            if (DesignVariant == 3)
                return darkMode ? Color.FromArgb(13, 17, 20) : Color.FromArgb(243, 246, 247);
            return darkMode ? Color.FromArgb(17, 20, 24) : Color.FromArgb(245, 247, 250);
        }

        private Color ThemeSurfaceColor()
        {
            return customColorsEnabled ? customSurfaceColor : (darkMode ? Color.FromArgb(28, 33, 40) : Color.White);
        }

        private Color ThemePrimaryTextColor()
        {
            return customColorsEnabled ? customPrimaryTextColor : (darkMode ? Color.FromArgb(238, 241, 245) : Color.FromArgb(25, 29, 35));
        }

        private Color ThemeSecondaryTextColor()
        {
            return customColorsEnabled ? customSecondaryTextColor : (darkMode ? Color.FromArgb(139, 149, 161) : Color.FromArgb(102, 111, 122));
        }

        private static void ApplyCaptionTheme(IntPtr windowHandle, bool useDarkMode)
        {
            int enabled = useDarkMode ? 1 : 0;
            DwmSetWindowAttribute(windowHandle, 20, ref enabled, sizeof(int));
            DwmSetWindowAttribute(windowHandle, 19, ref enabled, sizeof(int));

            Color background = useDarkMode ? Color.FromArgb(17, 20, 24) : Color.FromArgb(245, 247, 250);
            if (DesignVariant == 1)
                background = useDarkMode ? Color.FromArgb(12, 20, 23) : Color.FromArgb(243, 248, 248);
            else if (DesignVariant == 2)
                background = useDarkMode ? Color.FromArgb(22, 23, 27) : Color.FromArgb(248, 249, 251);
            else if (DesignVariant == 3)
                background = useDarkMode ? Color.FromArgb(13, 17, 20) : Color.FromArgb(243, 246, 247);
            Color foreground = useDarkMode ? Color.White : Color.FromArgb(24, 28, 34);
            int captionColor = ColorRef(background);
            int borderColor = ColorRef(background);
            int textColor = ColorRef(foreground);
            DwmSetWindowAttribute(windowHandle, 35, ref captionColor, sizeof(int));
            DwmSetWindowAttribute(windowHandle, 34, ref borderColor, sizeof(int));
            DwmSetWindowAttribute(windowHandle, 36, ref textColor, sizeof(int));
        }

        private static int ColorRef(Color color)
        {
            return color.R | (color.G << 8) | (color.B << 16);
        }

        private void ShowSettingsV15()
        {
            using (Form dialog = new Form())
            {
                dialog.Text = "PulseMute Test settings";
                dialog.ClientSize = new Size(420, 552);
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;
                dialog.ShowInTaskbar = false;
                dialog.TopMost = TopMost;
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.Font = new Font("Segoe UI", 10F);
                dialog.HandleCreated += delegate { ApplyCaptionTheme(dialog.Handle, darkMode); };

                Label heading = new Label();
                heading.Text = "Settings";
                heading.Font = new Font("Segoe UI Semibold", 17F, FontStyle.Bold);
                heading.SetBounds(20, 16, 260, 32);

                Label versionLabel = new Label();
                versionLabel.Text = EditionVersionText() + "  |  Created by Wrakeeb";
                versionLabel.Font = new Font("Segoe UI Semibold", 7.5F, FontStyle.Bold);
                versionLabel.TextAlign = ContentAlignment.MiddleCenter;
                versionLabel.SetBounds(20, 405, 380, 18);

                Label autoLabel = CreateSettingsLabel("Start with Windows", 20, 74);
                Label autoState = CreateSettingsStateLabel(20, 97);
                ToggleSwitch autoToggle = CreateToggleSwitch(354, 80, IsAutoStartEnabled());

                Panel separatorOne = CreateSeparator(20, 126, 380);

                Label taskbarLabel = CreateSettingsLabel("Hide window from taskbar", 20, 137);
                Label taskbarState = CreateSettingsStateLabel(20, 160);
                ToggleSwitch taskbarToggle = CreateToggleSwitch(354, 143, hideFromTaskbar);

                Panel separatorTwo = CreateSeparator(20, 189, 380);

                Label rememberLabel = CreateSettingsLabel("Remember window placement", 20, 200);
                Label rememberState = CreateSettingsStateLabel(20, 223);
                ToggleSwitch rememberToggle = CreateToggleSwitch(354, 206, rememberWindowPlacement);

                Label appearanceLabel = CreateSettingsLabel("Appearance", 20, 257);
                Label appearanceState = CreateSettingsStateLabel(20, 280);
                ToggleSwitch appearanceToggle = CreateToggleSwitch(354, 263, darkMode);

                Label customizationLabel = CreateSettingsLabel("Customization", 20, 307);
                Label customizationState = CreateSettingsStateLabel(20, 330);
                Button customizeButton = CreateSmallButton("Customize", new Point(290, 307));
                customizeButton.Size = new Size(110, 28);

                Label controllerLabel = CreateSettingsLabel("PlayStation controller", 20, 361);
                Label controllerState = CreateSettingsStateLabel(20, 384);
                controllerState.SetBounds(20, 384, 260, 18);
                Button controllerScanButton = CreateSmallButton("Rescan", new Point(290, 361));
                controllerScanButton.Size = new Size(110, 28);

                Label microphoneLabel = CreateSettingsLabel("Microphone", 20, 415);
                ThemedComboBox microphoneBox = new ThemedComboBox();
                microphoneBox.DropDownStyle = ComboBoxStyle.DropDownList;
                microphoneBox.FlatStyle = FlatStyle.Flat;
                microphoneBox.SetBounds(20, 440, 380, 30);

                List<MicDeviceInfo> devices = mic.GetCaptureDevices();
                devices.Insert(0, new MicDeviceInfo(null, "Windows default microphone"));
                int selectedIndex = 0;
                for (int i = 0; i < devices.Count; i++)
                {
                    microphoneBox.Items.Add(devices[i]);
                    if (!string.IsNullOrEmpty(mic.SelectedDeviceId) &&
                        string.Equals(devices[i].Id, mic.SelectedDeviceId, StringComparison.OrdinalIgnoreCase))
                        selectedIndex = i;
                }
                microphoneBox.SelectedIndex = selectedIndex;

                Button soundSettingsButton = CreateSmallButton("Sound settings", new Point(20, 478));
                soundSettingsButton.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
                soundSettingsButton.Size = new Size(150, 28);
                soundSettingsButton.Click += delegate { OpenWindowsSoundSettings(dialog); };

                Button doneButton = CreateSmallButton("Done", new Point(326, 478));
                doneButton.Size = new Size(74, 28);
                doneButton.Click += delegate { dialog.Close(); };
                dialog.AcceptButton = doneButton;

                Panel footerSeparator = CreateSeparator(20, 516, 380);
                versionLabel.SetBounds(20, 523, 380, 18);

                Action applyDialogTheme = delegate
                {
                    Color background = ThemeBackgroundColor();
                    Color foreground = ThemePrimaryTextColor();
                    Color secondary = ThemeSecondaryTextColor();
                    Color surface = ThemeSurfaceColor();
                    Color border = darkMode ? Color.FromArgb(54, 62, 72) : Color.FromArgb(205, 211, 219);
                    Color accent = AccentColor();

                    dialog.BackColor = background;
                    dialog.ForeColor = foreground;
                    foreach (Label label in new Label[] { heading, autoLabel, taskbarLabel, rememberLabel, appearanceLabel, customizationLabel, controllerLabel, microphoneLabel })
                        label.ForeColor = foreground;
                    versionLabel.ForeColor = secondary;

                    foreach (Label state in new Label[] { autoState, taskbarState, rememberState, appearanceState, customizationState, controllerState })
                        state.ForeColor = secondary;
                    autoState.Text = autoToggle.Checked ? "Enabled" : "Disabled";
                    taskbarState.Text = taskbarToggle.Checked ? "Enabled" : "Disabled";
                    rememberState.Text = rememberToggle.Checked ? "Enabled" : "Disabled";
                    appearanceState.Text = appearanceToggle.Checked ? "Dark theme" : "White theme";
                    customizationState.Text = customColorsEnabled ? "Custom colors" : "Default colors";
                    controllerState.Text = dualSense.StatusText;

                    foreach (ToggleSwitch toggle in new ToggleSwitch[] { autoToggle, taskbarToggle, rememberToggle, appearanceToggle })
                    {
                        toggle.OnColor = accent;
                        toggle.OffColor = darkMode ? Color.FromArgb(67, 75, 86) : Color.FromArgb(187, 194, 203);
                        toggle.ThumbColor = Color.White;
                        toggle.Invalidate();
                    }

                    microphoneBox.BackColor = surface;
                    microphoneBox.ForeColor = foreground;
                    microphoneBox.HighlightColor = accent;
                    microphoneBox.Invalidate();
                    foreach (Panel separator in new Panel[] { separatorOne, separatorTwo, footerSeparator })
                        separator.BackColor = border;
                    foreach (Button button in new Button[] { customizeButton, controllerScanButton, soundSettingsButton, doneButton })
                    {
                        button.BackColor = surface;
                        button.ForeColor = foreground;
                        button.FlatAppearance.BorderColor = border;
                        button.FlatAppearance.MouseOverBackColor = darkMode ? Color.FromArgb(39, 45, 54) : Color.FromArgb(235, 238, 242);
                    }

                    ApplyCaptionTheme(dialog.Handle, darkMode);
                    dialog.Invalidate(true);
                };

                bool changingAutoStart = false;
                autoToggle.CheckedChanged += delegate
                {
                    if (changingAutoStart)
                        return;
                    try
                    {
                        SetAutoStartEnabled(autoToggle.Checked);
                    }
                    catch (Exception ex)
                    {
                        changingAutoStart = true;
                        autoToggle.Checked = !autoToggle.Checked;
                        changingAutoStart = false;
                        MessageBox.Show(dialog, ex.Message, "PulseMute", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    applyDialogTheme();
                };

                taskbarToggle.CheckedChanged += delegate
                {
                    hideFromTaskbar = taskbarToggle.Checked;
                    ShowInTaskbar = !hideFromTaskbar;
                    SaveSettingsFile();
                    applyDialogTheme();
                };

                rememberToggle.CheckedChanged += delegate
                {
                    rememberWindowPlacement = rememberToggle.Checked;
                    SaveSettingsFile();
                    applyDialogTheme();
                };

                appearanceToggle.CheckedChanged += delegate
                {
                    if (darkMode == appearanceToggle.Checked)
                        return;
                    darkMode = appearanceToggle.Checked;
                    ApplyTheme();
                    SaveSettingsFile();
                    applyDialogTheme();
                };

                customizeButton.Click += delegate
                {
                    ShowColorCustomization(dialog, applyDialogTheme);
                    applyDialogTheme();
                };

                controllerScanButton.Click += delegate
                {
                    dualSense.Rescan();
                    controllerState.Text = "Searching...";
                };

                microphoneBox.SelectedIndexChanged += delegate
                {
                    MicDeviceInfo selected = microphoneBox.SelectedItem as MicDeviceInfo;
                    if (selected == null)
                        return;
                    mic.SelectedDeviceId = selected.Id;
                    SaveSettingsFile();
                    RefreshState();
                };

                dialog.Controls.Add(heading);
                dialog.Controls.Add(versionLabel);
                dialog.Controls.Add(autoLabel);
                dialog.Controls.Add(autoState);
                dialog.Controls.Add(autoToggle);
                dialog.Controls.Add(separatorOne);
                dialog.Controls.Add(taskbarLabel);
                dialog.Controls.Add(taskbarState);
                dialog.Controls.Add(taskbarToggle);
                dialog.Controls.Add(separatorTwo);
                dialog.Controls.Add(rememberLabel);
                dialog.Controls.Add(rememberState);
                dialog.Controls.Add(rememberToggle);
                dialog.Controls.Add(appearanceLabel);
                dialog.Controls.Add(appearanceState);
                dialog.Controls.Add(appearanceToggle);
                dialog.Controls.Add(customizationLabel);
                dialog.Controls.Add(customizationState);
                dialog.Controls.Add(customizeButton);
                dialog.Controls.Add(controllerLabel);
                dialog.Controls.Add(controllerState);
                dialog.Controls.Add(controllerScanButton);
                dialog.Controls.Add(microphoneLabel);
                dialog.Controls.Add(microphoneBox);
                dialog.Controls.Add(soundSettingsButton);
                dialog.Controls.Add(doneButton);
                dialog.Controls.Add(footerSeparator);
                Timer controllerStatusTimer = new Timer();
                controllerStatusTimer.Interval = 500;
                controllerStatusTimer.Tick += delegate { controllerState.Text = dualSense.StatusText; };
                controllerStatusTimer.Start();
                dialog.FormClosed += delegate
                {
                    controllerStatusTimer.Stop();
                    controllerStatusTimer.Dispose();
                };
                applyDialogTheme();
                dialog.ShowDialog(this);
            }
        }

        private void ShowColorCustomization(Form owner, Action refreshSettings)
        {
            using (Form dialog = new Form())
            {
                dialog.Text = "PulseMute customization";
                dialog.ClientSize = new Size(400, 420);
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;
                dialog.ShowInTaskbar = false;
                dialog.TopMost = owner.TopMost;
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.Font = new Font("Segoe UI", 10F);

                Label heading = CreateSettingsLabel("Customize colors", 20, 16);
                heading.Font = new Font("Segoe UI Semibold", 17F, FontStyle.Bold);
                heading.SetBounds(20, 16, 280, 34);

                string[] names = { "Accent", "Creator lines", "Background", "Control surface", "Primary text", "Secondary text" };
                Label[] labels = new Label[names.Length];
                Button[] swatches = new Button[names.Length];
                for (int i = 0; i < names.Length; i++)
                {
                    int y = 66 + (i * 47);
                    labels[i] = CreateSettingsLabel(names[i], 20, y + 4);
                    labels[i].SetBounds(20, y + 4, 210, 24);
                    swatches[i] = CreateColorSwatchButton(250, y);
                    dialog.Controls.Add(labels[i]);
                    dialog.Controls.Add(swatches[i]);
                }

                Button resetButton = CreateSmallButton("Reset defaults", new Point(20, 354));
                resetButton.Size = new Size(130, 30);
                Button closeButton = CreateSmallButton("Done", new Point(306, 354));
                closeButton.Size = new Size(74, 30);
                closeButton.Click += delegate { dialog.Close(); };
                dialog.AcceptButton = closeButton;

                Label footer = new Label();
                footer.Text = EditionVersionText() + "  |  Created by Wrakeeb";
                footer.Font = new Font("Segoe UI Semibold", 7.5F, FontStyle.Bold);
                footer.TextAlign = ContentAlignment.MiddleCenter;
                footer.SetBounds(20, 394, 360, 18);

                Action refreshDialog = delegate
                {
                    Color background = ThemeBackgroundColor();
                    Color foreground = ThemePrimaryTextColor();
                    Color secondary = ThemeSecondaryTextColor();
                    Color surface = ThemeSurfaceColor();
                    Color border = darkMode ? Color.FromArgb(54, 62, 72) : Color.FromArgb(205, 211, 219);
                    Color[] colors =
                    {
                        AccentColor(), CreatorLineColor(), ThemeBackgroundColor(), ThemeSurfaceColor(),
                        ThemePrimaryTextColor(), ThemeSecondaryTextColor()
                    };

                    dialog.BackColor = background;
                    heading.ForeColor = foreground;
                    footer.ForeColor = secondary;
                    foreach (Label label in labels)
                        label.ForeColor = foreground;
                    for (int i = 0; i < swatches.Length; i++)
                        StyleColorSwatch(swatches[i], colors[i], border);
                    foreach (Button button in new Button[] { resetButton, closeButton })
                    {
                        button.BackColor = surface;
                        button.ForeColor = foreground;
                        button.FlatAppearance.BorderColor = border;
                    }
                    ApplyCaptionTheme(dialog.Handle, darkMode);
                    dialog.Invalidate(true);
                };

                Action commitColors = delegate
                {
                    ApplyTheme();
                    SaveSettingsFile();
                    refreshSettings();
                    refreshDialog();
                };

                swatches[0].Click += delegate { PickCustomColor(dialog, AccentColor(), delegate(Color color) { customAccentColor = color; }, commitColors); };
                swatches[1].Click += delegate { PickCustomColor(dialog, CreatorLineColor(), delegate(Color color) { customCreatorColor = color; }, commitColors); };
                swatches[2].Click += delegate { PickCustomColor(dialog, ThemeBackgroundColor(), delegate(Color color) { customBackgroundColor = color; }, commitColors); };
                swatches[3].Click += delegate { PickCustomColor(dialog, ThemeSurfaceColor(), delegate(Color color) { customSurfaceColor = color; }, commitColors); };
                swatches[4].Click += delegate { PickCustomColor(dialog, ThemePrimaryTextColor(), delegate(Color color) { customPrimaryTextColor = color; }, commitColors); };
                swatches[5].Click += delegate { PickCustomColor(dialog, ThemeSecondaryTextColor(), delegate(Color color) { customSecondaryTextColor = color; }, commitColors); };

                resetButton.Click += delegate
                {
                    customColorsEnabled = false;
                    commitColors();
                };

                dialog.Controls.Add(heading);
                dialog.Controls.Add(resetButton);
                dialog.Controls.Add(closeButton);
                dialog.Controls.Add(footer);
                refreshDialog();
                dialog.ShowDialog(owner);
            }
        }

        private void PickCustomColor(Form owner, Color initialColor, Action<Color> assignColor, Action commitColors)
        {
            using (ColorDialog picker = new ColorDialog())
            {
                picker.Color = initialColor;
                picker.FullOpen = true;
                if (picker.ShowDialog(owner) != DialogResult.OK)
                    return;

                EnsureCustomColorsInitialized();
                assignColor(picker.Color);
                commitColors();
            }
        }

        private void EnsureCustomColorsInitialized()
        {
            if (customColorsEnabled)
                return;

            customAccentColor = AccentColor();
            customCreatorColor = CreatorLineColor();
            customBackgroundColor = ThemeBackgroundColor();
            customSurfaceColor = ThemeSurfaceColor();
            customPrimaryTextColor = ThemePrimaryTextColor();
            customSecondaryTextColor = ThemeSecondaryTextColor();
            customColorsEnabled = true;
        }

        private static Button CreateColorSwatchButton(int x, int y)
        {
            Button button = new Button();
            button.SetBounds(x, y, 130, 32);
            button.FlatStyle = FlatStyle.Flat;
            button.Cursor = Cursors.Hand;
            button.Font = new Font("Consolas", 8.5F, FontStyle.Bold);
            return button;
        }

        private static void StyleColorSwatch(Button button, Color color, Color border)
        {
            button.BackColor = color;
            button.ForeColor = ReadableTextColor(color);
            button.Text = "#" + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
            button.FlatAppearance.BorderColor = border;
        }

        private static Color ReadableTextColor(Color background)
        {
            int brightness = (background.R * 299 + background.G * 587 + background.B * 114) / 1000;
            return brightness >= 145 ? Color.FromArgb(20, 24, 29) : Color.White;
        }

        private static Label CreateSettingsLabel(string text, int x, int y)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold);
            label.SetBounds(x, y, 280, 22);
            return label;
        }

        private static string EditionVersionText()
        {
            if (DesignVariant == 1)
                return "PulseMute 1.5.1 Focus";
            if (DesignVariant == 2)
                return "PulseMute 1.5.2 Signal";
            if (DesignVariant == 3)
                return "PulseMute 1.5.3 Console";
            return "PulseMute Test 26.1.0.2-test";
        }

        private static Label CreateSettingsStateLabel(int x, int y)
        {
            Label label = new Label();
            label.Font = new Font("Segoe UI", 8F, FontStyle.Regular);
            label.SetBounds(x, y, 180, 18);
            return label;
        }

        private static ToggleSwitch CreateToggleSwitch(int x, int y, bool isChecked)
        {
            ToggleSwitch toggle = new ToggleSwitch();
            toggle.SetBounds(x, y, 46, 24);
            toggle.Checked = isChecked;
            toggle.Cursor = Cursors.Hand;
            return toggle;
        }

        private static RadioButton CreateThemeChoice(string text, int x, int y, bool isChecked)
        {
            RadioButton choice = new RadioButton();
            choice.Appearance = Appearance.Button;
            choice.FlatStyle = FlatStyle.Flat;
            choice.Text = text;
            choice.TextAlign = ContentAlignment.MiddleCenter;
            choice.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            choice.SetBounds(x, y, 90, 30);
            choice.Checked = isChecked;
            choice.Cursor = Cursors.Hand;
            return choice;
        }

        private static Panel CreateSeparator(int x, int y, int width)
        {
            Panel separator = new Panel();
            separator.SetBounds(x, y, width, 1);
            return separator;
        }

        private void ShowSettings()
        {
            using (Form dialog = new Form())
            {
                dialog.Text = "PulseMute Test settings";
                dialog.ClientSize = new Size(380, 330);
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;
                dialog.ShowInTaskbar = false;
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.BackColor = Color.FromArgb(17, 20, 24);
                dialog.ForeColor = Color.White;
                dialog.Font = new Font("Segoe UI", 10F);
                dialog.HandleCreated += delegate { ApplyCaptionTheme(dialog.Handle, darkMode); };

                Label heading = new Label();
                heading.Text = "Settings";
                heading.Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold);
                heading.SetBounds(18, 14, 210, 34);

                Label autoLabel = new Label();
                autoLabel.Text = "Start with Windows";
                autoLabel.SetBounds(20, 60, 205, 28);
                autoLabel.TextAlign = ContentAlignment.MiddleLeft;

                CheckBox autoToggle = new CheckBox();
                autoToggle.Appearance = Appearance.Button;
                autoToggle.FlatStyle = FlatStyle.Flat;
                autoToggle.FlatAppearance.BorderColor = Color.FromArgb(54, 62, 72);
                autoToggle.TextAlign = ContentAlignment.MiddleCenter;
                autoToggle.Cursor = Cursors.Hand;
                autoToggle.SetBounds(286, 57, 74, 30);
                autoToggle.Checked = IsAutoStartEnabled();
                autoToggle.Text = autoToggle.Checked ? "On" : "Off";
                autoToggle.BackColor = autoToggle.Checked ? Color.FromArgb(26, 124, 88) : Color.FromArgb(31, 36, 43);

                Label taskbarLabel = new Label();
                taskbarLabel.Text = "Hide window from taskbar";
                taskbarLabel.SetBounds(20, 101, 230, 28);
                taskbarLabel.TextAlign = ContentAlignment.MiddleLeft;

                CheckBox taskbarToggle = new CheckBox();
                taskbarToggle.Appearance = Appearance.Button;
                taskbarToggle.FlatStyle = FlatStyle.Flat;
                taskbarToggle.FlatAppearance.BorderColor = Color.FromArgb(54, 62, 72);
                taskbarToggle.TextAlign = ContentAlignment.MiddleCenter;
                taskbarToggle.Cursor = Cursors.Hand;
                taskbarToggle.SetBounds(286, 96, 74, 30);
                taskbarToggle.Checked = hideFromTaskbar;
                taskbarToggle.Text = taskbarToggle.Checked ? "On" : "Off";
                taskbarToggle.BackColor = taskbarToggle.Checked ? Color.FromArgb(26, 124, 88) : Color.FromArgb(31, 36, 43);

                Label rememberLabel = new Label();
                rememberLabel.Text = "Remember size and position";
                rememberLabel.SetBounds(20, 135, 245, 28);
                rememberLabel.TextAlign = ContentAlignment.MiddleLeft;

                CheckBox rememberToggle = new CheckBox();
                rememberToggle.Appearance = Appearance.Button;
                rememberToggle.FlatStyle = FlatStyle.Flat;
                rememberToggle.TextAlign = ContentAlignment.MiddleCenter;
                rememberToggle.Cursor = Cursors.Hand;
                rememberToggle.SetBounds(286, 134, 74, 30);
                rememberToggle.Checked = rememberWindowPlacement;
                rememberToggle.Text = rememberToggle.Checked ? "On" : "Off";

                Label appearanceLabel = new Label();
                appearanceLabel.Text = "Appearance";
                appearanceLabel.SetBounds(20, 176, 150, 28);
                appearanceLabel.TextAlign = ContentAlignment.MiddleLeft;

                RadioButton darkChoice = new RadioButton();
                darkChoice.Appearance = Appearance.Button;
                darkChoice.FlatStyle = FlatStyle.Flat;
                darkChoice.Text = "Dark";
                darkChoice.TextAlign = ContentAlignment.MiddleCenter;
                darkChoice.Cursor = Cursors.Hand;
                darkChoice.SetBounds(214, 175, 72, 30);
                darkChoice.Checked = darkMode;

                RadioButton lightChoice = new RadioButton();
                lightChoice.Appearance = Appearance.Button;
                lightChoice.FlatStyle = FlatStyle.Flat;
                lightChoice.Text = "White";
                lightChoice.TextAlign = ContentAlignment.MiddleCenter;
                lightChoice.Cursor = Cursors.Hand;
                lightChoice.SetBounds(288, 175, 72, 30);
                lightChoice.Checked = !darkMode;

                Label microphoneLabel = new Label();
                microphoneLabel.Text = "Microphone";
                microphoneLabel.SetBounds(20, 216, 340, 22);

                ComboBox microphoneBox = new ComboBox();
                microphoneBox.DropDownStyle = ComboBoxStyle.DropDownList;
                microphoneBox.FlatStyle = FlatStyle.Flat;
                microphoneBox.BackColor = Color.FromArgb(31, 36, 43);
                microphoneBox.ForeColor = Color.White;
                microphoneBox.SetBounds(20, 240, 340, 30);

                List<MicDeviceInfo> devices = mic.GetCaptureDevices();
                devices.Insert(0, new MicDeviceInfo(null, "Windows default microphone"));
                int selectedIndex = 0;
                for (int i = 0; i < devices.Count; i++)
                {
                    microphoneBox.Items.Add(devices[i]);
                    if (!string.IsNullOrEmpty(mic.SelectedDeviceId) &&
                        string.Equals(devices[i].Id, mic.SelectedDeviceId, StringComparison.OrdinalIgnoreCase))
                        selectedIndex = i;
                }
                microphoneBox.SelectedIndex = selectedIndex;

                Button soundSettingsButton = CreateSmallButton("Open sound settings", new Point(20, 288));
                soundSettingsButton.Size = new Size(178, 30);
                soundSettingsButton.Click += delegate { OpenWindowsSoundSettings(dialog); };

                Button closeButton = CreateSmallButton("Close", new Point(286, 289));
                closeButton.Size = new Size(74, 28);
                closeButton.Click += delegate { dialog.Close(); };
                dialog.AcceptButton = closeButton;

                Action applyDialogTheme = delegate
                {
                    Color background = darkMode ? Color.FromArgb(17, 20, 24) : Color.FromArgb(245, 247, 250);
                    Color foreground = darkMode ? Color.White : Color.FromArgb(24, 28, 34);
                    Color buttonBackground = darkMode ? Color.FromArgb(31, 36, 43) : Color.White;
                    Color border = darkMode ? Color.FromArgb(54, 62, 72) : Color.FromArgb(195, 202, 211);

                    dialog.BackColor = background;
                    dialog.ForeColor = foreground;
                    foreach (Label label in new Label[] { heading, autoLabel, taskbarLabel, rememberLabel, appearanceLabel, microphoneLabel })
                        label.ForeColor = foreground;

                    foreach (CheckBox toggle in new CheckBox[] { autoToggle, taskbarToggle, rememberToggle })
                    {
                        toggle.ForeColor = toggle.Checked ? Color.White : foreground;
                        toggle.BackColor = toggle.Checked ? Color.FromArgb(26, 124, 88) : buttonBackground;
                        toggle.FlatAppearance.BorderColor = border;
                        toggle.Text = toggle.Checked ? "On" : "Off";
                    }

                    foreach (RadioButton choice in new RadioButton[] { darkChoice, lightChoice })
                    {
                        choice.ForeColor = choice.Checked ? Color.White : foreground;
                        choice.BackColor = choice.Checked ? Color.FromArgb(193, 53, 69) : buttonBackground;
                        choice.FlatAppearance.BorderColor = border;
                    }

                    microphoneBox.BackColor = buttonBackground;
                    microphoneBox.ForeColor = foreground;
                    foreach (Button button in new Button[] { soundSettingsButton, closeButton })
                    {
                        button.BackColor = buttonBackground;
                        button.ForeColor = foreground;
                        button.FlatAppearance.BorderColor = border;
                        button.FlatAppearance.MouseOverBackColor = darkMode ? Color.FromArgb(42, 49, 59) : Color.FromArgb(232, 236, 241);
                    }

                    ApplyCaptionTheme(dialog.Handle, darkMode);
                    dialog.Invalidate(true);
                };

                bool changingAutoStart = false;
                autoToggle.CheckedChanged += delegate
                {
                    if (changingAutoStart)
                        return;

                    try
                    {
                        SetAutoStartEnabled(autoToggle.Checked);
                        applyDialogTheme();
                    }
                    catch (Exception ex)
                    {
                        changingAutoStart = true;
                        autoToggle.Checked = !autoToggle.Checked;
                        changingAutoStart = false;
                        applyDialogTheme();
                        MessageBox.Show(dialog, ex.Message, "PulseMute", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                };

                taskbarToggle.CheckedChanged += delegate
                {
                    hideFromTaskbar = taskbarToggle.Checked;
                    ShowInTaskbar = !hideFromTaskbar;
                    SaveSettingsFile();
                    applyDialogTheme();
                };

                rememberToggle.CheckedChanged += delegate
                {
                    rememberWindowPlacement = rememberToggle.Checked;
                    SaveSettingsFile();
                    applyDialogTheme();
                };

                darkChoice.CheckedChanged += delegate
                {
                    if (!darkChoice.Checked)
                        return;

                    darkMode = true;
                    ApplyTheme();
                    SaveSettingsFile();
                    applyDialogTheme();
                };

                lightChoice.CheckedChanged += delegate
                {
                    if (!lightChoice.Checked)
                        return;

                    darkMode = false;
                    ApplyTheme();
                    SaveSettingsFile();
                    applyDialogTheme();
                };

                microphoneBox.SelectedIndexChanged += delegate
                {
                    MicDeviceInfo selected = microphoneBox.SelectedItem as MicDeviceInfo;
                    if (selected == null)
                        return;

                    mic.SelectedDeviceId = selected.Id;
                    SaveSettingsFile();
                    RefreshState();
                };

                dialog.Controls.Add(heading);
                dialog.Controls.Add(autoLabel);
                dialog.Controls.Add(autoToggle);
                dialog.Controls.Add(taskbarLabel);
                dialog.Controls.Add(taskbarToggle);
                dialog.Controls.Add(rememberLabel);
                dialog.Controls.Add(rememberToggle);
                dialog.Controls.Add(appearanceLabel);
                dialog.Controls.Add(darkChoice);
                dialog.Controls.Add(lightChoice);
                dialog.Controls.Add(microphoneLabel);
                dialog.Controls.Add(microphoneBox);
                dialog.Controls.Add(soundSettingsButton);
                dialog.Controls.Add(closeButton);
                applyDialogTheme();
                dialog.ShowDialog(this);
            }
        }

        private static void OpenWindowsSoundSettings(IWin32Window owner)
        {
            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo("ms-settings:sound");
                startInfo.UseShellExecute = true;
                Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                MessageBox.Show(owner, ex.Message, "PulseMute", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ToggleMute()
        {
            try
            {
                bool next = !mic.GetMuted();
                mic.SetMuted(next);
                RefreshState();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "PulseMute", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                RefreshState();
            }
        }

        private void RefreshState()
        {
            try
            {
                bool muted = mic.GetMuted();
                deviceLabel.Text = mic.GetDeviceName();
                statusLabel.Text = muted ? "Muted" : "Live";
                statusLabel.BackColor = muted ? Color.FromArgb(160, 42, 57) : Color.FromArgb(26, 124, 88);
                toggleButton.Text = muted ? "Unmute" : "Mute";
                toggleButton.PrimaryColor = muted ? Color.FromArgb(193, 53, 69) : Color.FromArgb(24, 151, 104);
                toggleButton.SecondaryColor = muted ? Color.FromArgb(117, 35, 48) : Color.FromArgb(21, 91, 83);
                toggleButton.Invalidate();
                tray.Icon = appIcon;
                tray.Text = muted ? "PulseMute Test - muted" : "PulseMute Test - live";
            }
            catch (Exception ex)
            {
                statusLabel.Text = "No mic";
                statusLabel.BackColor = Color.FromArgb(103, 65, 25);
                toggleButton.Text = "No mic";
                toggleButton.PrimaryColor = Color.FromArgb(94, 69, 40);
                toggleButton.SecondaryColor = Color.FromArgb(132, 86, 37);
                deviceLabel.Text = ex.Message;
                tray.Icon = appIcon;
                tray.Text = "PulseMute Test - microphone unavailable";
            }
        }

        private void HideToTray()
        {
            Hide();
            WindowState = FormWindowState.Normal;
            tray.ShowBalloonTip(900, "PulseMute Test", "Listening for " + CurrentShortcutText(1) + " or " + CurrentShortcutText(2) + ".", ToolTipIcon.Info);
        }

        private void ShowFromTray()
        {
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        private void ToggleStayOnTop()
        {
            stayOnTop = !stayOnTop;
            TopMost = stayOnTop;
            ApplyTheme();
            SaveWindowSettings();
        }

        private void ApplyResponsiveLayout()
        {
            int width = Math.Max(1, ClientSize.Width);
            int height = Math.Max(1, ClientSize.Height);
            int pad = Clamp(Math.Min(width, height) / 18, 8, 22);
            int gap = Clamp(Math.Min(width, height) / 42, 4, 12);
            float scale = Math.Max(0.72f, Math.Min(1.8f, Math.Min(width / 300f, height / 380f)));
            float fontScale = Math.Max(0.9f, scale);

            if (DesignVariant != 0)
            {
                ApplyEditionLayout(width, height, pad, gap, scale, fontScale);
                return;
            }

            SetControlFont(titleLabel, "Segoe UI Semibold", 15f * fontScale, FontStyle.Bold);
            SetControlFont(statusLabel, "Segoe UI Semibold", 9.5f * fontScale, FontStyle.Bold);
            SetControlFont(deviceLabel, "Segoe UI", 9.5f * fontScale, FontStyle.Regular);
            SetControlFont(shortcutLabel, "Segoe UI", 9f * fontScale, FontStyle.Regular);
            SetControlFont(shortcutValueLabel, "Segoe UI Semibold", 9.5f * fontScale, FontStyle.Bold);
            SetControlFont(shortcutButton, "Segoe Fluent Icons", 11f * fontScale, FontStyle.Regular);
            SetControlFont(shortcutTwoLabel, "Segoe UI", 9f * fontScale, FontStyle.Regular);
            SetControlFont(shortcutTwoValueLabel, "Segoe UI Semibold", 9.5f * fontScale, FontStyle.Bold);
            SetControlFont(shortcutTwoButton, "Segoe Fluent Icons", 11f * fontScale, FontStyle.Regular);
            SetControlFont(settingsButton, "Segoe Fluent Icons", 11f * fontScale, FontStyle.Regular);
            SetControlFont(topButton, "Segoe Fluent Icons", 11f * fontScale, FontStyle.Regular);
            SetControlFont(refreshButton, "Segoe Fluent Icons", 11f * fontScale, FontStyle.Regular);
            SetControlFont(hideButton, "Segoe Fluent Icons", 11f * fontScale, FontStyle.Regular);
            SetControlFont(creditLabel, "Segoe UI Semibold", 7.8f * fontScale, FontStyle.Bold);

            int topRowHeight = Clamp((int)(28 * scale), 22, 42);
            int statusWidth = Clamp((int)(74 * scale), 54, Math.Max(54, width / 3));
            int topWidth = Clamp((int)(34 * scale), 30, 46);
            int settingsWidth = Clamp((int)(34 * scale), 28, 48);
            statusLabel.SetBounds(width - pad - statusWidth, pad, statusWidth, topRowHeight);
            topButton.SetBounds(statusLabel.Left - gap - topWidth, pad, topWidth, topRowHeight);
            settingsButton.SetBounds(topButton.Left - gap - settingsWidth, pad, settingsWidth, topRowHeight);
            int titleRight = Math.Max(pad, settingsButton.Left - gap);
            titleLabel.SetBounds(pad, pad - 2, Math.Max(20, titleRight - pad), topRowHeight + 8);

            int deviceTop = pad + topRowHeight + gap;
            deviceLabel.SetBounds(pad, deviceTop, Math.Max(20, width - (pad * 2)), Clamp((int)(24 * scale), 18, 34));

            int bottomButtonHeight = Clamp((int)(28 * scale), 24, 40);
            int bottomButtonWidth = Clamp((int)(40 * scale), 34, 52);
            int bottomTop = height - pad - bottomButtonHeight;
            refreshButton.SetBounds(pad, bottomTop, bottomButtonWidth, bottomButtonHeight);
            topButton.Height = topRowHeight;
            hideButton.SetBounds(width - pad - bottomButtonWidth, bottomTop, bottomButtonWidth, bottomButtonHeight);

            int creditHeight = Clamp((int)(20 * scale), 16, 28);
            int creditTop = bottomTop - gap - creditHeight;
            int creditTextWidth = Clamp((int)(138 * scale), 104, Math.Max(104, width - pad * 2));
            int creditLeft = (width - creditTextWidth) / 2;
            creditLabel.SetBounds(creditLeft, creditTop, creditTextWidth, creditHeight);
            int ruleY = creditTop + creditHeight / 2;
            int ruleGap = Clamp((int)(8 * scale), 5, 12);
            creditRuleLeft.SetBounds(pad, ruleY, Math.Max(0, creditLabel.Left - pad - ruleGap), 1);
            creditRuleRight.SetBounds(creditLabel.Right + ruleGap, ruleY, Math.Max(0, width - pad - creditLabel.Right - ruleGap), 1);

            int shortcutHeight = Clamp((int)(28 * scale), 22, 36);
            int shortcutTwoTop = creditLabel.Top - gap - shortcutHeight;
            int shortcutTop = shortcutTwoTop - gap - shortcutHeight;
            int shortcutButtonWidth = Clamp((int)(34 * scale), 30, 46);
            shortcutButton.SetBounds(width - pad - shortcutButtonWidth, shortcutTop, shortcutButtonWidth, shortcutHeight);
            int keyWidth = Clamp((int)(106 * scale), 86, 150);
            shortcutValueLabel.SetBounds(shortcutButton.Left - gap - keyWidth, shortcutTop, keyWidth, shortcutHeight);
            shortcutLabel.SetBounds(pad, shortcutTop, Math.Max(20, shortcutValueLabel.Left - pad - gap), shortcutHeight);
            shortcutTwoButton.SetBounds(width - pad - shortcutButtonWidth, shortcutTwoTop, shortcutButtonWidth, shortcutHeight);
            shortcutTwoValueLabel.SetBounds(shortcutTwoButton.Left - gap - keyWidth, shortcutTwoTop, keyWidth, shortcutHeight);
            shortcutTwoLabel.SetBounds(pad, shortcutTwoTop, Math.Max(20, shortcutTwoValueLabel.Left - pad - gap), shortcutHeight);

            int circleTop = deviceLabel.Bottom + gap;
            int circleBottom = shortcutTop - gap;
            int maxCircle = Math.Min(width - (pad * 2), circleBottom - circleTop);
            int circleSize = Clamp(maxCircle, 58, Math.Max(58, Math.Min(width - (pad * 2), height - (pad * 2))));
            int circleLeft = (width - circleSize) / 2;
            int adjustedCircleTop = circleTop + Math.Max(0, (circleBottom - circleTop - circleSize) / 2);
            toggleButton.SetBounds(circleLeft, adjustedCircleTop, circleSize, circleSize);
            SetControlFont(toggleButton, "Segoe UI Semibold", Math.Max(8f, circleSize / 9f), FontStyle.Bold);
        }

        private void ApplyEditionLayout(int width, int height, int pad, int gap, float scale, float fontScale)
        {
            SetControlFont(titleLabel, "Segoe UI Semibold", (DesignVariant == 3 ? 13f : 16f) * fontScale, FontStyle.Bold);
            SetControlFont(statusLabel, "Segoe UI Semibold", 9f * fontScale, FontStyle.Bold);
            SetControlFont(deviceLabel, "Segoe UI", 9f * fontScale, FontStyle.Regular);
            SetControlFont(shortcutLabel, "Segoe UI Semibold", 7.5f * fontScale, FontStyle.Bold);
            SetControlFont(shortcutValueLabel, "Segoe UI Semibold", 9f * fontScale, FontStyle.Bold);
            SetControlFont(shortcutButton, "Segoe Fluent Icons", 10.5f * fontScale, FontStyle.Regular);
            SetControlFont(settingsButton, "Segoe Fluent Icons", 10.5f * fontScale, FontStyle.Regular);
            SetControlFont(topButton, "Segoe Fluent Icons", 10.5f * fontScale, FontStyle.Regular);
            SetControlFont(refreshButton, "Segoe Fluent Icons", 10.5f * fontScale, FontStyle.Regular);
            SetControlFont(hideButton, "Segoe Fluent Icons", 10.5f * fontScale, FontStyle.Regular);
            SetControlFont(creditLabel, "Segoe UI Semibold", 7.3f * fontScale, FontStyle.Bold);

            if (DesignVariant == 1)
                ApplyFocusLayout(width, height, pad, gap, scale);
            else if (DesignVariant == 2)
                ApplySignalLayout(width, height, pad, gap, scale);
            else
                ApplyConsoleLayout(width, height, pad, gap, scale);
        }

        private void ApplyFocusLayout(int width, int height, int pad, int gap, float scale)
        {
            int topHeight = Clamp((int)(30 * scale), 24, 38);
            int iconSize = Clamp((int)(34 * scale), 30, 42);
            int statusWidth = Clamp((int)(76 * scale), 62, 92);
            statusLabel.SetBounds(width - pad - statusWidth, pad, statusWidth, topHeight);
            topButton.SetBounds(statusLabel.Left - gap - iconSize, pad, iconSize, topHeight);
            settingsButton.SetBounds(topButton.Left - gap - iconSize, pad, iconSize, topHeight);
            titleLabel.SetBounds(pad, pad - 2, Math.Max(80, settingsButton.Left - pad - gap), topHeight + 6);

            int rightX = Clamp((int)(width * 0.43f), 155, width - pad - 150);
            int deviceTop = pad + topHeight + gap;
            deviceLabel.SetBounds(rightX, deviceTop, Math.Max(120, width - rightX - pad), Clamp((int)(24 * scale), 20, 30));

            int bottomHeight = Clamp((int)(30 * scale), 26, 38);
            int bottomTop = height - pad - bottomHeight;
            refreshButton.SetBounds(rightX, bottomTop, iconSize, bottomHeight);
            hideButton.SetBounds(width - pad - iconSize, bottomTop, iconSize, bottomHeight);

            int creditHeight = Clamp((int)(18 * scale), 16, 24);
            int creditTop = bottomTop - gap - creditHeight;
            creditLabel.SetBounds(rightX + 36, creditTop, Math.Max(80, width - rightX - pad - 72), creditHeight);
            int ruleY = creditTop + creditHeight / 2;
            creditRuleLeft.SetBounds(rightX, ruleY, Math.Max(0, creditLabel.Left - rightX - gap), 1);
            creditRuleRight.SetBounds(creditLabel.Right + gap, ruleY, Math.Max(0, width - pad - creditLabel.Right - gap), 1);

            int shortcutHeight = Clamp((int)(31 * scale), 26, 38);
            int shortcutTop = deviceLabel.Bottom + gap * 2;
            int editWidth = iconSize;
            int keyWidth = Clamp((int)(72 * scale), 58, 92);
            shortcutButton.SetBounds(width - pad - editWidth, shortcutTop, editWidth, shortcutHeight);
            shortcutValueLabel.SetBounds(shortcutButton.Left - gap - keyWidth, shortcutTop, keyWidth, shortcutHeight);
            shortcutLabel.SetBounds(rightX, shortcutTop, Math.Max(35, shortcutValueLabel.Left - rightX - gap), shortcutHeight);

            int circleTop = deviceTop;
            int circleBottom = bottomTop;
            int circleSize = Math.Max(72, Math.Min(rightX - pad - gap, circleBottom - circleTop));
            toggleButton.SetBounds(pad + Math.Max(0, (rightX - pad - circleSize) / 2), circleTop + Math.Max(0, (circleBottom - circleTop - circleSize) / 2), circleSize, circleSize);
            SetControlFont(toggleButton, "Segoe UI Semibold", Math.Max(9f, circleSize / 9f), FontStyle.Bold);
        }

        private void ApplySignalLayout(int width, int height, int pad, int gap, float scale)
        {
            int iconSize = Clamp((int)(34 * scale), 30, 44);
            int topHeight = iconSize;
            settingsButton.SetBounds(pad, pad, iconSize, topHeight);
            topButton.SetBounds(width - pad - iconSize, pad, iconSize, topHeight);
            titleLabel.TextAlign = ContentAlignment.MiddleCenter;
            titleLabel.SetBounds(settingsButton.Right + gap, pad - 2, Math.Max(60, topButton.Left - settingsButton.Right - gap * 2), topHeight + 4);

            int statusHeight = Clamp((int)(27 * scale), 24, 34);
            int statusWidth = Clamp((int)(82 * scale), 66, 100);
            statusLabel.SetBounds((width - statusWidth) / 2, pad + topHeight + gap, statusWidth, statusHeight);
            int deviceTop = statusLabel.Bottom + gap;
            deviceLabel.TextAlign = ContentAlignment.MiddleCenter;
            deviceLabel.SetBounds(pad, deviceTop, Math.Max(80, width - pad * 2), Clamp((int)(24 * scale), 20, 30));

            int bottomHeight = Clamp((int)(31 * scale), 27, 40);
            int bottomTop = height - pad - bottomHeight;
            refreshButton.SetBounds(pad, bottomTop, iconSize, bottomHeight);
            hideButton.SetBounds(width - pad - iconSize, bottomTop, iconSize, bottomHeight);

            int creditHeight = Clamp((int)(18 * scale), 16, 24);
            int creditTop = bottomTop - gap - creditHeight;
            int creditWidth = Clamp((int)(145 * scale), 112, Math.Max(112, width - pad * 2));
            creditLabel.SetBounds((width - creditWidth) / 2, creditTop, creditWidth, creditHeight);
            int ruleY = creditTop + creditHeight / 2;
            creditRuleLeft.SetBounds(pad, ruleY, Math.Max(0, creditLabel.Left - pad - gap), 1);
            creditRuleRight.SetBounds(creditLabel.Right + gap, ruleY, Math.Max(0, width - pad - creditLabel.Right - gap), 1);

            int shortcutHeight = Clamp((int)(32 * scale), 27, 40);
            int shortcutTop = creditTop - gap - shortcutHeight;
            int editWidth = iconSize;
            int keyWidth = Clamp((int)(74 * scale), 58, 96);
            shortcutButton.SetBounds(width - pad - editWidth, shortcutTop, editWidth, shortcutHeight);
            shortcutValueLabel.SetBounds(shortcutButton.Left - gap - keyWidth, shortcutTop, keyWidth, shortcutHeight);
            shortcutLabel.SetBounds(pad, shortcutTop, Math.Max(35, shortcutValueLabel.Left - pad - gap), shortcutHeight);

            int muteTop = deviceLabel.Bottom + gap * 2;
            int muteBottom = shortcutTop - gap * 2;
            int muteHeight = Math.Max(64, Math.Min(112, muteBottom - muteTop));
            toggleButton.SetBounds(pad, muteTop + Math.Max(0, (muteBottom - muteTop - muteHeight) / 2), Math.Max(80, width - pad * 2), muteHeight);
            SetControlFont(toggleButton, "Segoe UI Semibold", Math.Max(12f, muteHeight / 5.5f), FontStyle.Bold);
        }

        private void ApplyConsoleLayout(int width, int height, int pad, int gap, float scale)
        {
            titleLabel.TextAlign = ContentAlignment.MiddleLeft;
            deviceLabel.TextAlign = ContentAlignment.MiddleLeft;
            int rightWidth = Clamp((int)(width * 0.36f), 120, 190);
            int rightX = width - pad - rightWidth;
            int titleHeight = Clamp((int)(28 * scale), 24, 36);
            titleLabel.SetBounds(pad, pad, Math.Max(100, rightX - pad - gap), titleHeight);
            statusLabel.SetBounds(rightX, pad, rightWidth, titleHeight);
            deviceLabel.SetBounds(pad, titleLabel.Bottom + gap, Math.Max(90, rightX - pad - gap), Clamp((int)(24 * scale), 20, 30));

            int toolbarHeight = Clamp((int)(31 * scale), 27, 38);
            int toolbarTop = height - pad - toolbarHeight;
            int iconSize = Clamp((int)(34 * scale), 30, 42);
            settingsButton.SetBounds(pad, toolbarTop, iconSize, toolbarHeight);
            topButton.SetBounds(settingsButton.Right + gap, toolbarTop, iconSize, toolbarHeight);
            refreshButton.SetBounds(topButton.Right + gap, toolbarTop, iconSize, toolbarHeight);
            hideButton.SetBounds(refreshButton.Right + gap, toolbarTop, iconSize, toolbarHeight);

            int creditHeight = Clamp((int)(18 * scale), 16, 24);
            int creditTop = toolbarTop - gap - creditHeight;
            creditLabel.SetBounds(pad, creditTop, Math.Max(90, rightX - pad - gap), creditHeight);
            creditLabel.TextAlign = ContentAlignment.MiddleLeft;
            creditRuleLeft.SetBounds(0, 0, 0, 0);
            creditRuleRight.SetBounds(pad, creditLabel.Bottom, Math.Max(40, rightX - pad - gap), 1);

            int shortcutHeight = Clamp((int)(34 * scale), 28, 42);
            int shortcutTop = deviceLabel.Bottom + gap * 2;
            int editWidth = iconSize;
            int keyWidth = Clamp((int)(72 * scale), 58, 92);
            shortcutButton.SetBounds(rightX - gap - editWidth, shortcutTop, editWidth, shortcutHeight);
            shortcutValueLabel.SetBounds(shortcutButton.Left - gap - keyWidth, shortcutTop, keyWidth, shortcutHeight);
            shortcutLabel.SetBounds(pad, shortcutTop, Math.Max(35, shortcutValueLabel.Left - pad - gap), shortcutHeight);

            int muteTop = statusLabel.Bottom + gap * 2;
            int muteBottom = height - pad;
            int muteSize = Math.Max(82, Math.Min(rightWidth, muteBottom - muteTop));
            toggleButton.SetBounds(rightX + Math.Max(0, (rightWidth - muteSize) / 2), muteTop + Math.Max(0, (muteBottom - muteTop - muteSize) / 2), muteSize, muteSize);
            SetControlFont(toggleButton, "Segoe UI Semibold", Math.Max(9f, muteSize / 8f), FontStyle.Bold);
        }

        private static int Clamp(int value, int minimum, int maximum)
        {
            return Math.Max(minimum, Math.Min(maximum, value));
        }

        private static void SetControlFont(Control control, string family, float size, FontStyle style)
        {
            float rounded = (float)Math.Round(size * 2f) / 2f;
            if (control.Font.FontFamily.Name == family && Math.Abs(control.Font.Size - rounded) < 0.1f && control.Font.Style == style)
                return;

            control.Font = new Font(family, rounded, style);
        }

        private void CaptureShortcut(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;

            Keys keyCode = e.KeyCode;
            if (keyCode == Keys.ControlKey || keyCode == Keys.ShiftKey || keyCode == Keys.Menu || keyCode == Keys.LWin || keyCode == Keys.RWin)
                return;

            int slot = captureShortcutSlot == 2 ? 2 : 1;
            captureShortcutSlot = 0;
            ApplyKeyboardShortcut(slot, (uint)keyCode, true);
        }

        private void DualSenseButtonPressed(object sender, DualSenseButtonEventArgs e)
        {
            if (IsDisposed || !IsHandleCreated)
                return;

            try
            {
                BeginInvoke((MethodInvoker)delegate
                {
                    if (captureShortcutSlot != 0)
                    {
                        int slot = captureShortcutSlot;
                        captureShortcutSlot = 0;
                        if (slot == 1)
                        {
                            shortcutSource = ShortcutSource.DualSense;
                            currentControllerButton = e.Button;
                            shortcutOneHeld = false;
                            shortcutValueLabel.Text = CurrentShortcutText(1);
                        }
                        else
                        {
                            secondShortcutSource = ShortcutSource.DualSense;
                            secondControllerButton = e.Button;
                            shortcutTwoHeld = false;
                            shortcutTwoValueLabel.Text = CurrentShortcutText(2);
                        }
                        SaveShortcut();
                        return;
                    }

                    if (ShortcutBindingMatcher.MatchesController(
                        shortcutSource, currentControllerButton,
                        secondShortcutSource, secondControllerButton,
                        e.Button))
                        ToggleMute();
                });
            }
            catch (InvalidOperationException)
            {
            }
        }

        private void AssignMouseShortcut(int slot, MouseHotkey button)
        {
            if (slot == 1)
            {
                shortcutSource = ShortcutSource.Mouse;
                currentMouseButton = button;
                shortcutOneHeld = false;
                shortcutValueLabel.Text = CurrentShortcutText(1);
            }
            else
            {
                secondShortcutSource = ShortcutSource.Mouse;
                secondMouseButton = button;
                shortcutTwoHeld = false;
                shortcutTwoValueLabel.Text = CurrentShortcutText(2);
            }
            SaveShortcut();
        }

        private void ApplyKeyboardShortcut(int slot, uint key, bool persist)
        {
            if (slot == 1)
            {
                currentKey = key;
                shortcutSource = ShortcutSource.Keyboard;
                shortcutOneHeld = false;
                shortcutValueLabel.Text = CurrentShortcutText(1);
            }
            else
            {
                secondKey = key;
                secondShortcutSource = ShortcutSource.Keyboard;
                shortcutTwoHeld = false;
                shortcutTwoValueLabel.Text = CurrentShortcutText(2);
            }
            if (persist)
                SaveShortcut();
        }

        private void LoadShortcut()
        {
            string path = ConfigPath();
            if (!File.Exists(path))
                return;

            try
            {
                string[] lines = File.ReadAllLines(path);
                uint key = currentKey;
                ShortcutSource source = shortcutSource;
                DualSenseButton controllerButton = currentControllerButton;
                MouseHotkey mouseButton = currentMouseButton;
                uint keyTwo = secondKey;
                ShortcutSource sourceTwo = secondShortcutSource;
                DualSenseButton controllerButtonTwo = secondControllerButton;
                MouseHotkey mouseButtonTwo = secondMouseButton;
                bool legacyComboSetting = false;
                foreach (string line in lines)
                {
                    if (line.StartsWith("Modifiers=", StringComparison.OrdinalIgnoreCase))
                        legacyComboSetting = true;
                    if (line.StartsWith("Key=", StringComparison.OrdinalIgnoreCase))
                        uint.TryParse(line.Substring("Key=".Length), out key);
                    if (line.StartsWith("ShortcutSource=", StringComparison.OrdinalIgnoreCase))
                    {
                        ShortcutSource parsedSource;
                        if (Enum.TryParse(line.Substring("ShortcutSource=".Length), true, out parsedSource))
                            source = parsedSource;
                    }
                    if (line.StartsWith("ControllerButton=", StringComparison.OrdinalIgnoreCase))
                    {
                        DualSenseButton parsedButton;
                        if (Enum.TryParse(line.Substring("ControllerButton=".Length), true, out parsedButton))
                            controllerButton = parsedButton;
                    }
                    if (line.StartsWith("MouseButton=", StringComparison.OrdinalIgnoreCase))
                    {
                        MouseHotkey parsedButton;
                        if (Enum.TryParse(line.Substring("MouseButton=".Length), true, out parsedButton))
                            mouseButton = parsedButton;
                    }
                    if (line.StartsWith("Key2=", StringComparison.OrdinalIgnoreCase))
                        uint.TryParse(line.Substring("Key2=".Length), out keyTwo);
                    if (line.StartsWith("ShortcutSource2=", StringComparison.OrdinalIgnoreCase))
                    {
                        ShortcutSource parsedSource;
                        if (Enum.TryParse(line.Substring("ShortcutSource2=".Length), true, out parsedSource))
                            sourceTwo = parsedSource;
                    }
                    if (line.StartsWith("ControllerButton2=", StringComparison.OrdinalIgnoreCase))
                    {
                        DualSenseButton parsedButton;
                        if (Enum.TryParse(line.Substring("ControllerButton2=".Length), true, out parsedButton))
                            controllerButtonTwo = parsedButton;
                    }
                    if (line.StartsWith("MouseButton2=", StringComparison.OrdinalIgnoreCase))
                    {
                        MouseHotkey parsedButton;
                        if (Enum.TryParse(line.Substring("MouseButton2=".Length), true, out parsedButton))
                            mouseButtonTwo = parsedButton;
                    }
                }

                if (legacyComboSetting)
                {
                    currentKey = (uint)Keys.F8;
                    shortcutSource = ShortcutSource.Keyboard;
                    secondKey = (uint)Keys.F9;
                    secondShortcutSource = ShortcutSource.Keyboard;
                    shortcutValueLabel.Text = CurrentShortcutText(1);
                    shortcutTwoValueLabel.Text = CurrentShortcutText(2);
                    SaveShortcut();
                }
                else if (key != 0)
                {
                    currentKey = key;
                    shortcutSource = source;
                    currentControllerButton = controllerButton;
                    currentMouseButton = mouseButton;
                    secondKey = keyTwo == 0 ? (uint)Keys.F9 : keyTwo;
                    secondShortcutSource = sourceTwo;
                    secondControllerButton = controllerButtonTwo;
                    secondMouseButton = mouseButtonTwo;
                    shortcutValueLabel.Text = CurrentShortcutText(1);
                    shortcutTwoValueLabel.Text = CurrentShortcutText(2);
                }
            }
            catch
            {
                shortcutValueLabel.Text = CurrentShortcutText(1);
                shortcutTwoValueLabel.Text = CurrentShortcutText(2);
            }
        }

        private void SaveShortcut()
        {
            if (windowSettingsReady)
            {
                SaveSettingsFile();
            }
            else
            {
                string path = ConfigPath();
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.WriteAllText(path,
                    "Key=" + currentKey + Environment.NewLine +
                    "ShortcutSource=" + shortcutSource + Environment.NewLine +
                    "ControllerButton=" + currentControllerButton + Environment.NewLine +
                    "MouseButton=" + currentMouseButton + Environment.NewLine +
                    "Key2=" + secondKey + Environment.NewLine +
                    "ShortcutSource2=" + secondShortcutSource + Environment.NewLine +
                    "ControllerButton2=" + secondControllerButton + Environment.NewLine +
                    "MouseButton2=" + secondMouseButton + Environment.NewLine);
            }
        }

        private void LoadWindowSettings()
        {
            string path = ConfigPath();
            if (!File.Exists(path))
                return;

            try
            {
                string[] lines = File.ReadAllLines(path);
                int x = Left;
                int y = Top;
                int width = Width;
                int height = Height;
                bool savedTopMost = stayOnTop;
                bool hasBounds = false;

                foreach (string line in lines)
                {
                    if (line.StartsWith("X=", StringComparison.OrdinalIgnoreCase))
                    {
                        hasBounds = int.TryParse(line.Substring("X=".Length), out x) || hasBounds;
                    }
                    else if (line.StartsWith("Y=", StringComparison.OrdinalIgnoreCase))
                    {
                        hasBounds = int.TryParse(line.Substring("Y=".Length), out y) || hasBounds;
                    }
                    else if (line.StartsWith("Width=", StringComparison.OrdinalIgnoreCase))
                    {
                        hasBounds = int.TryParse(line.Substring("Width=".Length), out width) || hasBounds;
                    }
                    else if (line.StartsWith("Height=", StringComparison.OrdinalIgnoreCase))
                    {
                        hasBounds = int.TryParse(line.Substring("Height=".Length), out height) || hasBounds;
                    }
                    else if (line.StartsWith("TopMost=", StringComparison.OrdinalIgnoreCase))
                    {
                        bool.TryParse(line.Substring("TopMost=".Length), out savedTopMost);
                    }
                    else if (line.StartsWith("DeviceId=", StringComparison.OrdinalIgnoreCase))
                    {
                        string savedDeviceId = line.Substring("DeviceId=".Length);
                        mic.SelectedDeviceId = string.IsNullOrEmpty(savedDeviceId) ? null : savedDeviceId;
                    }
                    else if (line.StartsWith("HideFromTaskbar=", StringComparison.OrdinalIgnoreCase))
                    {
                        bool.TryParse(line.Substring("HideFromTaskbar=".Length), out hideFromTaskbar);
                    }
                    else if (line.StartsWith("RememberWindowPlacement=", StringComparison.OrdinalIgnoreCase))
                    {
                        bool.TryParse(line.Substring("RememberWindowPlacement=".Length), out rememberWindowPlacement);
                    }
                    else if (line.StartsWith("Theme=", StringComparison.OrdinalIgnoreCase))
                    {
                        darkMode = !line.Substring("Theme=".Length).Equals("White", StringComparison.OrdinalIgnoreCase);
                    }
                    else if (line.StartsWith("CustomColors=", StringComparison.OrdinalIgnoreCase))
                    {
                        bool.TryParse(line.Substring("CustomColors=".Length), out customColorsEnabled);
                    }
                    else if (line.StartsWith("CustomAccent=", StringComparison.OrdinalIgnoreCase))
                    {
                        TryParseColor(line.Substring("CustomAccent=".Length), ref customAccentColor);
                    }
                    else if (line.StartsWith("CustomCreator=", StringComparison.OrdinalIgnoreCase))
                    {
                        TryParseColor(line.Substring("CustomCreator=".Length), ref customCreatorColor);
                    }
                    else if (line.StartsWith("CustomBackground=", StringComparison.OrdinalIgnoreCase))
                    {
                        TryParseColor(line.Substring("CustomBackground=".Length), ref customBackgroundColor);
                    }
                    else if (line.StartsWith("CustomSurface=", StringComparison.OrdinalIgnoreCase))
                    {
                        TryParseColor(line.Substring("CustomSurface=".Length), ref customSurfaceColor);
                    }
                    else if (line.StartsWith("CustomPrimaryText=", StringComparison.OrdinalIgnoreCase))
                    {
                        TryParseColor(line.Substring("CustomPrimaryText=".Length), ref customPrimaryTextColor);
                    }
                    else if (line.StartsWith("CustomSecondaryText=", StringComparison.OrdinalIgnoreCase))
                    {
                        TryParseColor(line.Substring("CustomSecondaryText=".Length), ref customSecondaryTextColor);
                    }
                }

                Rectangle savedBounds = new Rectangle(x, y, Math.Max(MinimumSize.Width, width), Math.Max(MinimumSize.Height, height));
                if (rememberWindowPlacement && hasBounds && IsOnAnyScreen(savedBounds))
                {
                    StartPosition = FormStartPosition.Manual;
                    Bounds = savedBounds;
                }

                stayOnTop = savedTopMost;
                TopMost = stayOnTop;
                ShowInTaskbar = !hideFromTaskbar;
                ApplyTheme();
                ApplyResponsiveLayout();
            }
            catch
            {
            }
        }

        private void SaveWindowSettings()
        {
            if (!windowSettingsReady || WindowState != FormWindowState.Normal)
                return;

            SaveSettingsFile();
        }

        private void SaveSettingsFile()
        {
            string path = ConfigPath();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(
                path,
                "Key=" + currentKey + Environment.NewLine +
                "ShortcutSource=" + shortcutSource + Environment.NewLine +
                "ControllerButton=" + currentControllerButton + Environment.NewLine +
                "MouseButton=" + currentMouseButton + Environment.NewLine +
                "Key2=" + secondKey + Environment.NewLine +
                "ShortcutSource2=" + secondShortcutSource + Environment.NewLine +
                "ControllerButton2=" + secondControllerButton + Environment.NewLine +
                "MouseButton2=" + secondMouseButton + Environment.NewLine +
                "X=" + Left + Environment.NewLine +
                "Y=" + Top + Environment.NewLine +
                "Width=" + Width + Environment.NewLine +
                "Height=" + Height + Environment.NewLine +
                "TopMost=" + stayOnTop + Environment.NewLine +
                "DeviceId=" + (mic.SelectedDeviceId ?? string.Empty) + Environment.NewLine +
                "HideFromTaskbar=" + hideFromTaskbar + Environment.NewLine +
                "RememberWindowPlacement=" + rememberWindowPlacement + Environment.NewLine +
                "Theme=" + (darkMode ? "Dark" : "White") + Environment.NewLine +
                "CustomColors=" + customColorsEnabled + Environment.NewLine +
                "CustomAccent=" + ColorValue(customAccentColor) + Environment.NewLine +
                "CustomCreator=" + ColorValue(customCreatorColor) + Environment.NewLine +
                "CustomBackground=" + ColorValue(customBackgroundColor) + Environment.NewLine +
                "CustomSurface=" + ColorValue(customSurfaceColor) + Environment.NewLine +
                "CustomPrimaryText=" + ColorValue(customPrimaryTextColor) + Environment.NewLine +
                "CustomSecondaryText=" + ColorValue(customSecondaryTextColor) + Environment.NewLine);
        }

        private static string ColorValue(Color color)
        {
            return color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
        }

        private static void TryParseColor(string value, ref Color target)
        {
            int rgb;
            if (value.Length == 6 && int.TryParse(value, System.Globalization.NumberStyles.HexNumber, null, out rgb))
                target = Color.FromArgb((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255);
        }

        private static bool IsOnAnyScreen(Rectangle bounds)
        {
            foreach (Screen screen in Screen.AllScreens)
            {
                if (Rectangle.Intersect(screen.WorkingArea, bounds).Width > 40 &&
                    Rectangle.Intersect(screen.WorkingArea, bounds).Height > 40)
                    return true;
            }

            return false;
        }

        private static bool IsAutoStartEnabled()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", false))
            {
                return key != null && key.GetValue("PulseMuteTestAutoStart") != null;
            }
        }

        private static void SetAutoStartEnabled(bool enabled)
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
            {
                if (key == null)
                    throw new InvalidOperationException("Windows startup settings are unavailable.");

                if (enabled)
                    key.SetValue("PulseMuteTestAutoStart", "\"" + Application.ExecutablePath + "\"");
                else
                    key.DeleteValue("PulseMuteTestAutoStart", false);
            }
        }

        private static string ConfigPath()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "PulseMute", "Test", "settings.txt");
        }

        private static string HotkeyText(uint key)
        {
            return ((Keys)key).ToString();
        }

        private string CurrentShortcutText(int slot)
        {
            if (slot == 2)
            {
                if (secondShortcutSource == ShortcutSource.Mouse)
                    return MouseHotkeyProtocol.ButtonName(secondMouseButton);
                return secondShortcutSource == ShortcutSource.DualSense
                    ? "PS: " + DualSenseProtocol.ButtonName(secondControllerButton)
                    : HotkeyText(secondKey);
            }
            if (shortcutSource == ShortcutSource.Mouse)
                return MouseHotkeyProtocol.ButtonName(currentMouseButton);
            return shortcutSource == ShortcutSource.DualSense
                ? "PS: " + DualSenseProtocol.ButtonName(currentControllerButton)
                : HotkeyText(currentKey);
        }

        private void InstallKeyboardHook()
        {
            if (keyboardHook != IntPtr.Zero)
                return;

            keyboardHook = SetWindowsHookEx(WhKeyboardLl, keyboardProc, GetModuleHandle(null), 0);
            shortcutValueLabel.Text = CurrentShortcutText(1);
            shortcutTwoValueLabel.Text = CurrentShortcutText(2);
        }

        private void UninstallKeyboardHook()
        {
            if (keyboardHook == IntPtr.Zero)
                return;

            UnhookWindowsHookEx(keyboardHook);
            keyboardHook = IntPtr.Zero;
        }

        private void InstallMouseHook()
        {
            if (mouseHook != IntPtr.Zero)
                return;
            mouseHook = SetWindowsHookExMouse(WhMouseLl, mouseProc, GetModuleHandle(null), 0);
        }

        private void UninstallMouseHook()
        {
            if (mouseHook == IntPtr.Zero)
                return;
            UnhookWindowsHookEx(mouseHook);
            mouseHook = IntPtr.Zero;
        }

        private IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && captureShortcutSlot == 0)
            {
                int message = wParam.ToInt32();
                Keys key = (Keys)Marshal.ReadInt32(lParam);

                if (message == WmKeydown || message == WmSyskeydown)
                {
                    bool shouldToggle = false;
                    if (ShortcutBindingMatcher.MatchesKeyboard(shortcutSource, currentKey, key) && !shortcutOneHeld)
                    {
                        shortcutOneHeld = true;
                        shouldToggle = true;
                    }
                    if (ShortcutBindingMatcher.MatchesKeyboard(secondShortcutSource, secondKey, key) && !shortcutTwoHeld)
                    {
                        shortcutTwoHeld = true;
                        shouldToggle = true;
                    }
                    if (shouldToggle)
                        BeginInvoke((MethodInvoker)delegate { ToggleMute(); });
                }
                else if (message == WmKeyup || message == WmSyskeyup)
                {
                    if ((uint)key == currentKey)
                        shortcutOneHeld = false;
                    if ((uint)key == secondKey)
                        shortcutTwoHeld = false;
                }
            }

            return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
        }

        private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                MsllHookStruct data = (MsllHookStruct)Marshal.PtrToStructure(lParam, typeof(MsllHookStruct));
                MouseHotkey button;
                if ((data.Flags & LlMhfInjected) == 0 && MouseHotkeyProtocol.TryParseMessage(wParam.ToInt32(), data.MouseData, out button))
                {
                    if (captureShortcutSlot != 0)
                    {
                        int slot = captureShortcutSlot;
                        captureShortcutSlot = 0;
                        if (InvokeRequired)
                            BeginInvoke((MethodInvoker)delegate { AssignMouseShortcut(slot, button); });
                        else
                            AssignMouseShortcut(slot, button);
                        return new IntPtr(1);
                    }

                    if (!IsPulseMuteWindow(data.Point) && ShortcutBindingMatcher.MatchesMouse(
                        shortcutSource, currentMouseButton,
                        secondShortcutSource, secondMouseButton,
                        button))
                    {
                        BeginInvoke((MethodInvoker)delegate { ToggleMute(); });
                    }
                }
            }
            return CallNextHookEx(mouseHook, nCode, wParam, lParam);
        }

        private bool IsPulseMuteWindow(NativePoint point)
        {
            IntPtr window = WindowFromPoint(point);
            for (int depth = 0; window != IntPtr.Zero && depth < 8; depth++)
            {
                IntPtr root = GetAncestor(window, GaRoot);
                if (root == Handle)
                    return true;
                window = GetWindow(root, GwOwner);
            }
            return false;
        }

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
        private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        private struct NativePoint
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MsllHookStruct
        {
            public NativePoint Point;
            public uint MouseData;
            public uint Flags;
            public uint Time;
            public IntPtr ExtraInfo;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", EntryPoint = "SetWindowsHookEx", SetLastError = true)]
        private static extern IntPtr SetWindowsHookExMouse(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern IntPtr WindowFromPoint(NativePoint point);

        [DllImport("user32.dll")]
        private static extern IntPtr GetAncestor(IntPtr hwnd, int flags);

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindow(IntPtr hwnd, uint command);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int valueSize);
    }

    internal static class ShortcutBindingMatcher
    {
        public static bool MatchesKeyboard(ShortcutSource source, uint assignedKey, Keys pressedKey)
        {
            return source == ShortcutSource.Keyboard && assignedKey == (uint)pressedKey;
        }

        public static bool MatchesController(
            ShortcutSource sourceOne, DualSenseButton buttonOne,
            ShortcutSource sourceTwo, DualSenseButton buttonTwo,
            DualSenseButton pressedButton)
        {
            return (sourceOne == ShortcutSource.DualSense && buttonOne == pressedButton) ||
                (sourceTwo == ShortcutSource.DualSense && buttonTwo == pressedButton);
        }

        public static bool MatchesMouse(
            ShortcutSource sourceOne, MouseHotkey buttonOne,
            ShortcutSource sourceTwo, MouseHotkey buttonTwo,
            MouseHotkey pressedButton)
        {
            return (sourceOne == ShortcutSource.Mouse && buttonOne == pressedButton) ||
                (sourceTwo == ShortcutSource.Mouse && buttonTwo == pressedButton);
        }
    }

    internal enum ShortcutSource
    {
        Keyboard,
        DualSense,
        Mouse
    }

    internal enum MouseHotkey
    {
        Left,
        Right,
        Middle,
        XButton1,
        XButton2,
        WheelUp,
        WheelDown,
        WheelLeft,
        WheelRight
    }

    internal static class MouseHotkeyProtocol
    {
        private const int WmLButtonDown = 0x0201;
        private const int WmRButtonDown = 0x0204;
        private const int WmMButtonDown = 0x0207;
        private const int WmMouseWheel = 0x020A;
        private const int WmXButtonDown = 0x020B;
        private const int WmMouseHWheel = 0x020E;

        public static bool TryParseMessage(int message, uint mouseData, out MouseHotkey button)
        {
            button = MouseHotkey.Left;
            switch (message)
            {
                case WmLButtonDown: button = MouseHotkey.Left; return true;
                case WmRButtonDown: button = MouseHotkey.Right; return true;
                case WmMButtonDown: button = MouseHotkey.Middle; return true;
                case WmXButtonDown:
                    int xButton = (int)((mouseData >> 16) & 0xFFFF);
                    if (xButton == 1) { button = MouseHotkey.XButton1; return true; }
                    if (xButton == 2) { button = MouseHotkey.XButton2; return true; }
                    return false;
                case WmMouseWheel:
                    short wheelDelta = unchecked((short)((mouseData >> 16) & 0xFFFF));
                    if (wheelDelta == 0) return false;
                    button = wheelDelta > 0 ? MouseHotkey.WheelUp : MouseHotkey.WheelDown;
                    return true;
                case WmMouseHWheel:
                    short horizontalDelta = unchecked((short)((mouseData >> 16) & 0xFFFF));
                    if (horizontalDelta == 0) return false;
                    button = horizontalDelta > 0 ? MouseHotkey.WheelRight : MouseHotkey.WheelLeft;
                    return true;
                default:
                    return false;
            }
        }

        public static string ButtonName(MouseHotkey button)
        {
            switch (button)
            {
                case MouseHotkey.Left: return "Mouse 1";
                case MouseHotkey.Right: return "Mouse 2";
                case MouseHotkey.Middle: return "Mouse 3";
                case MouseHotkey.XButton1: return "Mouse 4";
                case MouseHotkey.XButton2: return "Mouse 5";
                case MouseHotkey.WheelUp: return "Wheel Up";
                case MouseHotkey.WheelDown: return "Wheel Down";
                case MouseHotkey.WheelLeft: return "Wheel Left";
                case MouseHotkey.WheelRight: return "Wheel Right";
                default: return "Mouse";
            }
        }
    }

    [Flags]
    internal enum DualSenseButton : ulong
    {
        None = 0,
        DPadUp = 1UL << 0,
        DPadRight = 1UL << 1,
        DPadDown = 1UL << 2,
        DPadLeft = 1UL << 3,
        Square = 1UL << 4,
        Cross = 1UL << 5,
        Circle = 1UL << 6,
        Triangle = 1UL << 7,
        L1 = 1UL << 8,
        R1 = 1UL << 9,
        L2 = 1UL << 10,
        R2 = 1UL << 11,
        Create = 1UL << 12,
        Options = 1UL << 13,
        L3 = 1UL << 14,
        R3 = 1UL << 15,
        PS = 1UL << 16,
        Touchpad = 1UL << 17,
        MicrophoneMute = 1UL << 18,
        EdgeFnLeft = 1UL << 19,
        EdgeFnRight = 1UL << 20,
        EdgeLeftPaddle = 1UL << 21,
        EdgeRightPaddle = 1UL << 22
    }

    internal sealed class DualSenseButtonEventArgs : EventArgs
    {
        public DualSenseButton Button { get; private set; }

        public DualSenseButtonEventArgs(DualSenseButton button)
        {
            Button = button;
        }
    }

    internal static class DualSenseProtocol
    {
        private static readonly DualSenseButton[] AllButtons =
        {
            DualSenseButton.DPadUp, DualSenseButton.DPadRight, DualSenseButton.DPadDown, DualSenseButton.DPadLeft,
            DualSenseButton.Square, DualSenseButton.Cross, DualSenseButton.Circle, DualSenseButton.Triangle,
            DualSenseButton.L1, DualSenseButton.R1, DualSenseButton.L2, DualSenseButton.R2,
            DualSenseButton.Create, DualSenseButton.Options, DualSenseButton.L3, DualSenseButton.R3,
            DualSenseButton.PS, DualSenseButton.Touchpad, DualSenseButton.MicrophoneMute,
            DualSenseButton.EdgeFnLeft, DualSenseButton.EdgeFnRight,
            DualSenseButton.EdgeLeftPaddle, DualSenseButton.EdgeRightPaddle
        };

        public static DualSenseButton[] Buttons
        {
            get { return (DualSenseButton[])AllButtons.Clone(); }
        }

        public static bool TryParseReport(byte[] report, int count, out DualSenseButton buttons)
        {
            buttons = DualSenseButton.None;
            if (report == null || count <= 0 || count > report.Length)
                return false;

            int commonOffset;
            if (report[0] == 0x01)
            {
                commonOffset = 1;
            }
            else if (report[0] == 0x31)
            {
                commonOffset = 2;
            }
            else
            {
                return false;
            }

            int buttonOffset = commonOffset + 7;
            if (count <= buttonOffset + 1)
                return false;

            byte buttons0 = report[buttonOffset];
            byte buttons1 = report[buttonOffset + 1];
            byte buttons2 = count > buttonOffset + 2 ? report[buttonOffset + 2] : (byte)0;
            int hat = buttons0 & 0x0F;

            if (hat == 0 || hat == 1 || hat == 7) buttons |= DualSenseButton.DPadUp;
            if (hat == 1 || hat == 2 || hat == 3) buttons |= DualSenseButton.DPadRight;
            if (hat == 3 || hat == 4 || hat == 5) buttons |= DualSenseButton.DPadDown;
            if (hat == 5 || hat == 6 || hat == 7) buttons |= DualSenseButton.DPadLeft;

            if ((buttons0 & 0x10) != 0) buttons |= DualSenseButton.Square;
            if ((buttons0 & 0x20) != 0) buttons |= DualSenseButton.Cross;
            if ((buttons0 & 0x40) != 0) buttons |= DualSenseButton.Circle;
            if ((buttons0 & 0x80) != 0) buttons |= DualSenseButton.Triangle;
            if ((buttons1 & 0x01) != 0) buttons |= DualSenseButton.L1;
            if ((buttons1 & 0x02) != 0) buttons |= DualSenseButton.R1;
            if ((buttons1 & 0x04) != 0) buttons |= DualSenseButton.L2;
            if ((buttons1 & 0x08) != 0) buttons |= DualSenseButton.R2;
            if ((buttons1 & 0x10) != 0) buttons |= DualSenseButton.Create;
            if ((buttons1 & 0x20) != 0) buttons |= DualSenseButton.Options;
            if ((buttons1 & 0x40) != 0) buttons |= DualSenseButton.L3;
            if ((buttons1 & 0x80) != 0) buttons |= DualSenseButton.R3;
            if ((buttons2 & 0x01) != 0) buttons |= DualSenseButton.PS;
            if ((buttons2 & 0x02) != 0) buttons |= DualSenseButton.Touchpad;
            if ((buttons2 & 0x04) != 0) buttons |= DualSenseButton.MicrophoneMute;
            if ((buttons2 & 0x10) != 0) buttons |= DualSenseButton.EdgeFnLeft;
            if ((buttons2 & 0x20) != 0) buttons |= DualSenseButton.EdgeFnRight;
            if ((buttons2 & 0x40) != 0) buttons |= DualSenseButton.EdgeLeftPaddle;
            if ((buttons2 & 0x80) != 0) buttons |= DualSenseButton.EdgeRightPaddle;
            return true;
        }

        public static string ButtonName(DualSenseButton button)
        {
            switch (button)
            {
                case DualSenseButton.DPadUp: return "D-pad Up";
                case DualSenseButton.DPadRight: return "D-pad Right";
                case DualSenseButton.DPadDown: return "D-pad Down";
                case DualSenseButton.DPadLeft: return "D-pad Left";
                case DualSenseButton.Square: return "Square";
                case DualSenseButton.Cross: return "Cross";
                case DualSenseButton.Circle: return "Circle";
                case DualSenseButton.Triangle: return "Triangle";
                case DualSenseButton.L1: return "L1";
                case DualSenseButton.R1: return "R1";
                case DualSenseButton.L2: return "L2";
                case DualSenseButton.R2: return "R2";
                case DualSenseButton.Create: return "Create";
                case DualSenseButton.Options: return "Options";
                case DualSenseButton.L3: return "L3";
                case DualSenseButton.R3: return "R3";
                case DualSenseButton.PS: return "PS";
                case DualSenseButton.Touchpad: return "Touchpad";
                case DualSenseButton.MicrophoneMute: return "Mute";
                case DualSenseButton.EdgeFnLeft: return "Fn Left";
                case DualSenseButton.EdgeFnRight: return "Fn Right";
                case DualSenseButton.EdgeLeftPaddle: return "Left Paddle";
                case DualSenseButton.EdgeRightPaddle: return "Right Paddle";
                default: return "Unknown";
            }
        }

        public static byte[] CreateBluetoothEnhancedModeReport()
        {
            byte[] report = new byte[78];
            report[0] = 0x31;
            report[1] = 0x00;
            report[2] = 0x10;
            uint crc = ComputeBluetoothCrc(report, 74);
            report[74] = (byte)(crc & 0xFF);
            report[75] = (byte)((crc >> 8) & 0xFF);
            report[76] = (byte)((crc >> 16) & 0xFF);
            report[77] = (byte)((crc >> 24) & 0xFF);
            return report;
        }

        public static uint ComputeBluetoothCrc(byte[] data, int count)
        {
            uint crc = 0xFFFFFFFF;
            crc = UpdateCrc(crc, 0xA2);
            for (int i = 0; i < count; i++)
                crc = UpdateCrc(crc, data[i]);
            return ~crc;
        }

        private static uint UpdateCrc(uint crc, byte value)
        {
            crc ^= value;
            for (int bit = 0; bit < 8; bit++)
                crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xEDB88320 : crc >> 1;
            return crc;
        }
    }

    internal sealed class DualSenseControllerService : IDisposable
    {
        private const int SonyVendorId = 0x054C;
        private const int DualSenseProductId = 0x0CE6;
        private const int DualSenseEdgeProductId = 0x0DF2;
        private readonly object streamLock = new object();
        private volatile bool running;
        private volatile bool forceRescan;
        private volatile string statusText = "Not connected";
        private System.Threading.Thread worker;
        private HidStream activeStream;

        public event EventHandler<DualSenseButtonEventArgs> ButtonPressed;

        public string StatusText
        {
            get { return statusText; }
        }

        public void Start()
        {
            if (running)
                return;
            running = true;
            worker = new System.Threading.Thread(ReadLoop);
            worker.IsBackground = true;
            worker.Name = "PulseMute DualSense input";
            worker.Start();
        }

        public void Rescan()
        {
            forceRescan = true;
            statusText = "Searching...";
            CloseActiveStream();
        }

        public void Stop()
        {
            running = false;
            forceRescan = true;
            CloseActiveStream();
            if (worker != null && worker.IsAlive)
                worker.Join(1500);
            worker = null;
            statusText = "Not connected";
        }

        public void Dispose()
        {
            Stop();
        }

        private void ReadLoop()
        {
            while (running)
            {
                forceRescan = false;
                HidDevice device = FindController();
                if (device == null)
                {
                    statusText = "Not connected";
                    WaitForRescan(1000);
                    continue;
                }

                HidStream stream = null;
                try
                {
                    OpenConfiguration configuration = new OpenConfiguration();
                    configuration.SetOption(OpenOption.Exclusive, false);
                    device.TryOpen(configuration, out stream);
                }
                catch
                {
                }
                if (stream == null)
                {
                    statusText = "Controller is busy";
                    WaitForRescan(1000);
                    continue;
                }

                lock (streamLock)
                    activeStream = stream;

                try
                {
                    stream.ReadTimeout = 500;
                    stream.WriteTimeout = 500;
                    TryEnableBluetoothEnhancedMode(device, stream);
                    statusText = ControllerName(device) + " connected";
                    int reportLength = 78;
                    try { reportLength = Math.Max(78, device.GetMaxInputReportLength()); }
                    catch { }
                    byte[] report = new byte[reportLength];
                    DualSenseButton previousButtons = DualSenseButton.None;
                    bool hasPreviousReport = false;

                    while (running && !forceRescan)
                    {
                        try
                        {
                            int count = stream.Read(report, 0, report.Length);
                            DualSenseButton buttons;
                            if (!DualSenseProtocol.TryParseReport(report, count, out buttons))
                                continue;

                            if (!hasPreviousReport)
                            {
                                previousButtons = buttons;
                                hasPreviousReport = true;
                                continue;
                            }

                            DualSenseButton pressed = buttons & ~previousButtons;
                            previousButtons = buttons;
                            RaisePressedButtons(pressed);
                        }
                        catch (TimeoutException)
                        {
                        }
                        catch (IOException)
                        {
                            break;
                        }
                        catch (ObjectDisposedException)
                        {
                            break;
                        }
                        catch
                        {
                            break;
                        }
                    }
                }
                finally
                {
                    lock (streamLock)
                    {
                        if (ReferenceEquals(activeStream, stream))
                            activeStream = null;
                    }
                    try { stream.Dispose(); }
                    catch { }
                }

                if (running)
                {
                    statusText = "Reconnecting...";
                    WaitForRescan(500);
                }
            }
        }

        private static HidDevice FindController()
        {
            HidDevice best = null;
            int bestLength = 0;
            try
            {
                foreach (HidDevice device in DeviceList.Local.GetHidDevices(SonyVendorId))
                {
                    if (device.ProductID != DualSenseProductId && device.ProductID != DualSenseEdgeProductId)
                        continue;
                    try
                    {
                        int length = device.GetMaxInputReportLength();
                        if (length >= 10 && length > bestLength)
                        {
                            best = device;
                            bestLength = length;
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
            return best;
        }

        private static string ControllerName(HidDevice device)
        {
            if (device.ProductID == DualSenseEdgeProductId)
                return "DualSense Edge";
            return "DualSense";
        }

        private static void TryEnableBluetoothEnhancedMode(HidDevice device, HidStream stream)
        {
            try
            {
                if (device.GetMaxInputReportLength() >= 78 && device.GetMaxOutputReportLength() >= 78)
                    stream.Write(DualSenseProtocol.CreateBluetoothEnhancedModeReport());
            }
            catch
            {
                // Basic reports still provide the standard controls if enhanced mode is unavailable.
            }
        }

        private void RaisePressedButtons(DualSenseButton pressed)
        {
            if (pressed == DualSenseButton.None)
                return;
            EventHandler<DualSenseButtonEventArgs> handler = ButtonPressed;
            if (handler == null)
                return;
            foreach (DualSenseButton button in DualSenseProtocol.Buttons)
            {
                if ((pressed & button) != 0)
                    handler(this, new DualSenseButtonEventArgs(button));
            }
        }

        private void CloseActiveStream()
        {
            lock (streamLock)
            {
                if (activeStream != null)
                {
                    try { activeStream.Dispose(); }
                    catch { }
                    activeStream = null;
                }
            }
        }

        private void WaitForRescan(int milliseconds)
        {
            int waited = 0;
            while (running && !forceRescan && waited < milliseconds)
            {
                System.Threading.Thread.Sleep(100);
                waited += 100;
            }
        }
    }

    internal sealed class ThemedComboBox : ComboBox
    {
        public Color HighlightColor = Color.FromArgb(34, 139, 111);

        public ThemedComboBox()
        {
            DrawMode = DrawMode.OwnerDrawFixed;
            ItemHeight = 22;
        }

        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= Items.Count)
                return;

            bool highlighted = DroppedDown && (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            Color background = highlighted ? HighlightColor : BackColor;
            Color foreground = highlighted ? Color.White : ForeColor;

            using (SolidBrush brush = new SolidBrush(background))
                e.Graphics.FillRectangle(brush, e.Bounds);

            Rectangle paintBounds = e.Bounds;
            if (!DroppedDown)
            {
                int arrowWidth = SystemInformation.VerticalScrollBarWidth;
                paintBounds = new Rectangle(0, 0, Math.Max(1, ClientSize.Width - arrowWidth), ClientSize.Height);
                using (SolidBrush brush = new SolidBrush(BackColor))
                    e.Graphics.FillRectangle(brush, paintBounds);
            }

            Rectangle textBounds = new Rectangle(paintBounds.Left + 5, paintBounds.Top, Math.Max(1, paintBounds.Width - 8), paintBounds.Height);
            TextRenderer.DrawText(
                e.Graphics,
                Convert.ToString(Items[e.Index]),
                Font,
                textBounds,
                foreground,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);

            if (highlighted)
                e.DrawFocusRectangle();
        }
    }

    internal sealed class ToggleSwitch : CheckBox
    {
        public Color OnColor = Color.FromArgb(34, 139, 111);
        public Color OffColor = Color.FromArgb(67, 75, 86);
        public Color ThumbColor = Color.White;

        public ToggleSwitch()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            TabStop = true;
        }

        protected override void OnCheckedChanged(EventArgs e)
        {
            base.OnCheckedChanged(e);
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.Clear(Parent == null ? Color.Transparent : Parent.BackColor);

            Rectangle track = new Rectangle(1, 3, Math.Max(1, Width - 2), Math.Max(1, Height - 6));
            int radius = track.Height / 2;
            using (GraphicsPath path = RoundedPath(track, radius))
            using (SolidBrush trackBrush = new SolidBrush(Checked ? OnColor : OffColor))
            using (SolidBrush thumbBrush = new SolidBrush(ThumbColor))
            {
                graphics.FillPath(trackBrush, path);
                int thumbSize = Math.Max(8, Height - 10);
                int thumbX = Checked ? Width - thumbSize - 5 : 5;
                graphics.FillEllipse(thumbBrush, thumbX, (Height - thumbSize) / 2, thumbSize, thumbSize);
            }

            if (Focused)
                ControlPaint.DrawFocusRectangle(graphics, ClientRectangle);
        }

        private static GraphicsPath RoundedPath(Rectangle bounds, int radius)
        {
            int diameter = Math.Max(2, radius * 2);
            GraphicsPath path = new GraphicsPath();
            path.AddArc(bounds.Left, bounds.Top, diameter, diameter, 90, 180);
            path.AddArc(bounds.Right - diameter, bounds.Top, diameter, diameter, 270, 180);
            path.CloseFigure();
            return path;
        }
    }

    internal sealed class RoundButton : Button
    {
        public Color PrimaryColor = Color.FromArgb(24, 151, 104);
        public Color SecondaryColor = Color.FromArgb(21, 91, 83);
        public int ShapeStyle;

        protected override void OnPaint(PaintEventArgs pevent)
        {
            Graphics g = pevent.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Parent == null ? Color.Black : Parent.BackColor);

            Rectangle face = new Rectangle(2, 2, Math.Max(1, Width - 5), Math.Max(1, Height - 5));
            Rectangle shadow = new Rectangle(6, 8, Math.Max(1, Width - 12), Math.Max(1, Height - 14));
            using (GraphicsPath path = CreateShapePath(face))
            using (GraphicsPath shadowPath = CreateShapePath(shadow))
            using (LinearGradientBrush brush = new LinearGradientBrush(ClientRectangle, PrimaryColor, SecondaryColor, 45f))
            using (SolidBrush shadowBrush = new SolidBrush(Color.FromArgb(55, Color.Black)))
            using (Pen pen = new Pen(Color.FromArgb(80, Color.White), 2))
            {
                g.FillPath(shadowBrush, shadowPath);
                g.FillPath(brush, path);
                g.DrawPath(pen, path);
            }

            TextRenderer.DrawText(
                g,
                Text,
                Font,
                ClientRectangle,
                ForeColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        }

        private GraphicsPath CreateShapePath(Rectangle bounds)
        {
            GraphicsPath path = new GraphicsPath();
            if (ShapeStyle == 0)
            {
                path.AddEllipse(bounds);
                return path;
            }

            int radius = ShapeStyle == 1 ? Math.Max(8, bounds.Height / 2) : Math.Max(8, Math.Min(bounds.Width, bounds.Height) / 7);
            int diameter = Math.Min(Math.Min(bounds.Width, bounds.Height), radius * 2);
            path.AddArc(bounds.Left, bounds.Top, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Top, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    internal static class IconFactory
    {
        public static Icon Create(bool muted, bool warning)
        {
            Bitmap bitmap = new Bitmap(32, 32);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);

                Color fill = warning ? Color.FromArgb(210, 132, 47) : muted ? Color.FromArgb(204, 54, 70) : Color.FromArgb(34, 169, 114);
                using (SolidBrush bg = new SolidBrush(fill))
                using (Pen white = new Pen(Color.White, 3))
                using (SolidBrush whiteBrush = new SolidBrush(Color.White))
                {
                    white.StartCap = LineCap.Round;
                    white.EndCap = LineCap.Round;

                    g.FillEllipse(bg, 1, 1, 30, 30);
                    FillRoundedRectangle(g, whiteBrush, new Rectangle(13, 7, 6, 13), 3);
                    g.DrawArc(white, 9, 13, 14, 12, 0, 180);
                    g.DrawLine(white, 16, 25, 16, 28);
                    g.DrawLine(white, 12, 28, 20, 28);

                    if (muted || warning)
                        g.DrawLine(white, 9, 8, 23, 24);
                }
            }

            IntPtr handle = bitmap.GetHicon();
            Icon icon = (Icon)Icon.FromHandle(handle).Clone();
            DestroyIcon(handle);
            bitmap.Dispose();
            return icon;
        }

        private static void FillRoundedRectangle(Graphics graphics, Brush brush, Rectangle bounds, int radius)
        {
            int diameter = radius * 2;
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(bounds.Left, bounds.Top, diameter, diameter, 180, 90);
                path.AddArc(bounds.Right - diameter, bounds.Top, diameter, diameter, 270, 90);
                path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
                path.AddArc(bounds.Left, bounds.Bottom - diameter, diameter, diameter, 90, 90);
                path.CloseFigure();
                graphics.FillPath(brush, path);
            }
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool DestroyIcon(IntPtr hIcon);
    }

    internal sealed class MicDeviceInfo
    {
        public readonly string Id;
        public readonly string Name;

        public MicDeviceInfo(string id, string name)
        {
            Id = id;
            Name = name;
        }

        public override string ToString()
        {
            return Name;
        }
    }

    internal sealed class MicController
    {
        public string SelectedDeviceId { get; set; }

        public bool GetMuted()
        {
            using (ComReleaser<IAudioEndpointVolume> endpoint = GetEndpointVolume())
            {
                bool muted;
                endpoint.Value.GetMute(out muted).ThrowIfFailed();
                return muted;
            }
        }

        public void SetMuted(bool muted)
        {
            using (ComReleaser<IAudioEndpointVolume> endpoint = GetEndpointVolume())
            {
                endpoint.Value.SetMute(muted, Guid.Empty).ThrowIfFailed();
            }
        }

        public string GetDeviceName()
        {
            IMMDevice device = GetCaptureDevice();
            try
            {
                return GetDeviceFriendlyName(device);
            }
            finally
            {
                Marshal.ReleaseComObject(device);
            }
        }

        public List<MicDeviceInfo> GetCaptureDevices()
        {
            List<MicDeviceInfo> devices = new List<MicDeviceInfo>();
            IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)(new MMDeviceEnumerator());
            try
            {
                IMMDeviceCollection collection;
                enumerator.EnumAudioEndpoints(EDataFlow.Capture, 1, out collection).ThrowIfFailed();
                try
                {
                    uint count;
                    collection.GetCount(out count).ThrowIfFailed();
                    for (uint i = 0; i < count; i++)
                    {
                        IMMDevice device;
                        collection.Item(i, out device).ThrowIfFailed();
                        try
                        {
                            devices.Add(new MicDeviceInfo(GetDeviceId(device), GetDeviceFriendlyName(device)));
                        }
                        finally
                        {
                            Marshal.ReleaseComObject(device);
                        }
                    }
                }
                finally
                {
                    Marshal.ReleaseComObject(collection);
                }
            }
            finally
            {
                Marshal.ReleaseComObject(enumerator);
            }

            devices.Sort(delegate(MicDeviceInfo left, MicDeviceInfo right)
            {
                return string.Compare(left.Name, right.Name, StringComparison.CurrentCultureIgnoreCase);
            });
            return devices;
        }

        private ComReleaser<IAudioEndpointVolume> GetEndpointVolume()
        {
            IMMDevice device = GetCaptureDevice();
            try
            {
                Guid iid = typeof(IAudioEndpointVolume).GUID;
                object obj;
                device.Activate(ref iid, 23, IntPtr.Zero, out obj).ThrowIfFailed();
                return new ComReleaser<IAudioEndpointVolume>((IAudioEndpointVolume)obj);
            }
            finally
            {
                Marshal.ReleaseComObject(device);
            }
        }

        private IMMDevice GetCaptureDevice()
        {
            IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)(new MMDeviceEnumerator());
            try
            {
                IMMDevice device;
                int result;
                if (!string.IsNullOrEmpty(SelectedDeviceId))
                {
                    result = enumerator.GetDevice(SelectedDeviceId, out device);
                }
                else
                {
                    result = enumerator.GetDefaultAudioEndpoint(EDataFlow.Capture, ERole.Communications, out device);
                    if (result < 0)
                        result = enumerator.GetDefaultAudioEndpoint(EDataFlow.Capture, ERole.Multimedia, out device);
                }
                result.ThrowIfFailed();
                return device;
            }
            finally
            {
                Marshal.ReleaseComObject(enumerator);
            }
        }

        private static string GetDeviceId(IMMDevice device)
        {
            IntPtr idPointer;
            device.GetId(out idPointer).ThrowIfFailed();
            try
            {
                return Marshal.PtrToStringUni(idPointer);
            }
            finally
            {
                Marshal.FreeCoTaskMem(idPointer);
            }
        }

        private static string GetDeviceFriendlyName(IMMDevice device)
        {
            IPropertyStore store;
            device.OpenPropertyStore(0, out store).ThrowIfFailed();
            try
            {
                PropertyKey key = new PropertyKey(new Guid(0xA45C254E, 0xDF1C, 0x4EFD, 0x80, 0x20, 0x67, 0xD1, 0x46, 0xA8, 0x50, 0xE0), 14);
                PropVariant value;
                store.GetValue(ref key, out value).ThrowIfFailed();
                try
                {
                    return string.IsNullOrEmpty(value.Value) ? "Unnamed microphone" : value.Value;
                }
                finally
                {
                    PropVariantClear(ref value);
                }
            }
            finally
            {
                Marshal.ReleaseComObject(store);
            }
        }

        [DllImport("ole32.dll")]
        private static extern int PropVariantClear(ref PropVariant propVariant);
    }

    internal sealed class ComReleaser<T> : IDisposable where T : class
    {
        public readonly T Value;

        public ComReleaser(T value)
        {
            Value = value;
        }

        public void Dispose()
        {
            if (Value != null && Marshal.IsComObject(Value))
                Marshal.ReleaseComObject(Value);
        }
    }

    internal static class HResultExtensions
    {
        public static void ThrowIfFailed(this int hresult)
        {
            if (hresult < 0)
                Marshal.ThrowExceptionForHR(hresult);
        }
    }

    internal enum EDataFlow
    {
        Render,
        Capture,
        All
    }

    internal enum ERole
    {
        Console,
        Multimedia,
        Communications
    }

    [ComImport]
    [Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    internal class MMDeviceEnumerator
    {
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6")]
    internal interface IMMDeviceEnumerator
    {
        int EnumAudioEndpoints(EDataFlow dataFlow, uint dwStateMask, out IMMDeviceCollection ppDevices);
        int GetDefaultAudioEndpoint(EDataFlow dataFlow, ERole role, out IMMDevice ppDevice);
        int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string pwstrId, out IMMDevice ppDevice);
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E")]
    internal interface IMMDeviceCollection
    {
        int GetCount(out uint pcDevices);
        int Item(uint nDevice, out IMMDevice ppDevice);
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("D666063F-1587-4E43-81F1-B948E807363F")]
    internal interface IMMDevice
    {
        int Activate(ref Guid iid, int dwClsCtx, IntPtr pActivationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
        int OpenPropertyStore(int stgmAccess, out IPropertyStore ppProperties);
        int GetId(out IntPtr ppstrId);
        int GetState(out uint pdwState);
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99")]
    internal interface IPropertyStore
    {
        int GetCount(out uint cProps);
        int GetAt(uint iProp, out PropertyKey pkey);
        int GetValue(ref PropertyKey key, out PropVariant pv);
        int SetValue(ref PropertyKey key, ref PropVariant propvar);
        int Commit();
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("5CDF2C82-841E-4546-9722-0CF74078229A")]
    internal interface IAudioEndpointVolume
    {
        int RegisterControlChangeNotify(IntPtr pNotify);
        int UnregisterControlChangeNotify(IntPtr pNotify);
        int GetChannelCount(out uint pnChannelCount);
        int SetMasterVolumeLevel(float fLevelDB, Guid pguidEventContext);
        int SetMasterVolumeLevelScalar(float fLevel, Guid pguidEventContext);
        int GetMasterVolumeLevel(out float pfLevelDB);
        int GetMasterVolumeLevelScalar(out float pfLevel);
        int SetChannelVolumeLevel(uint nChannel, float fLevelDB, Guid pguidEventContext);
        int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, Guid pguidEventContext);
        int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
        int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, Guid pguidEventContext);
        int GetMute([MarshalAs(UnmanagedType.Bool)] out bool pbMute);
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct PropertyKey
    {
        private readonly Guid formatId;
        private readonly int propertyId;

        public PropertyKey(Guid formatId, int propertyId)
        {
            this.formatId = formatId;
            this.propertyId = propertyId;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct PropVariant
    {
        private readonly ushort vt;
        private readonly ushort reserved1;
        private readonly ushort reserved2;
        private readonly ushort reserved3;
        private readonly IntPtr pointer;
        private readonly int pointer2;

        public string Value
        {
            get { return vt == 31 && pointer != IntPtr.Zero ? Marshal.PtrToStringUni(pointer) : null; }
        }
    }
}
